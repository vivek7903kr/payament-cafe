import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { getDailySeries } from "@/lib/queries";
import {
  daysBetween,
  isValidYmd,
  istYmd,
  rangeFromYmd,
  toDateTimeLocal,
} from "@/lib/dates";

export const dynamic = "force-dynamic";

// Text cells starting with = + - @ are prefixed so spreadsheets never run them as formulas.
function cell(v: string | number | null, text = false): string {
  if (v === null || v === undefined) return "";
  let s = String(v);
  if (text && /^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  if (/[",\n\r]/.test(s)) s = `"${s.replace(/"/g, '""')}"`;
  return s;
}
const line = (cells: string[]) => cells.join(",");

type TxWithUser = Awaited<ReturnType<typeof loadTransactions>>[number];

function loadTransactions(where: { transactionDate?: { gte: Date; lt: Date } }) {
  return db.transaction.findMany({
    where,
    orderBy: { transactionDate: "asc" },
    include: { createdBy: { select: { name: true } } },
  });
}

function transactionRows(txs: TxWithUser[]): string[] {
  const rows = [
    line(["Date", "Time", "Amount (INR)", "Payment mode", "Order reference", "Customer", "Notes", "Staff", "Transaction ID"]),
  ];
  for (const t of txs) {
    rows.push(
      line([
        istYmd(t.transactionDate),
        toDateTimeLocal(t.transactionDate).slice(11), // IST
        t.amount.toFixed(2),
        t.paymentMode,
        cell(t.orderReference, true),
        cell(t.customerName, true),
        cell(t.notes, true),
        cell(t.createdBy.name, true),
        t.id,
      ])
    );
  }
  return rows;
}

function csv(rows: string[], filename: string) {
  // BOM so Excel opens the file as UTF-8
  return new NextResponse("\uFEFF" + rows.join("\r\n") + "\r\n", {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
}

export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return new NextResponse("Unauthorized", { status: 401 });
  if (session.role !== "ADMIN") return new NextResponse("Forbidden", { status: 403 });

  const sp = req.nextUrl.searchParams;
  const kind = sp.get("kind") === "daily" ? "daily" : "transactions";

  // Full backup of every payment ever recorded (used before a reset)
  if (kind === "transactions" && sp.get("all") === "1") {
    const txs = await loadTransactions({});
    return csv(transactionRows(txs), `cafe-all-payments-backup_${istYmd()}.csv`);
  }

  const from = sp.get("from");
  const to = sp.get("to");
  if (!isValidYmd(from) || !isValidYmd(to) || from > to) {
    return new NextResponse("Invalid date range", { status: 400 });
  }
  if (daysBetween(from, to) > 366) {
    return new NextResponse("Date range can be at most 366 days", { status: 400 });
  }

  if (kind === "daily") {
    const series = await getDailySeries(from, to);
    const rows = [
      line(["Date", "Cash (INR)", "UPI (INR)", "Card (INR)", "Other (INR)", "Total (INR)", "Transactions"]),
    ];
    for (const d of series) {
      rows.push(
        line([
          d.date,
          d.byMode.CASH.toFixed(2),
          d.byMode.UPI.toFixed(2),
          d.byMode.CARD.toFixed(2),
          d.byMode.OTHER.toFixed(2),
          d.total.toFixed(2),
          String(d.count),
        ])
      );
    }
    return csv(rows, `cafe-daily-revenue_${from}_to_${to}.csv`);
  }

  const { start, end } = rangeFromYmd(from, to);
  const txs = await loadTransactions({ transactionDate: { gte: start, lt: end } });
  return csv(transactionRows(txs), `cafe-transactions_${from}_to_${to}.csv`);
}
