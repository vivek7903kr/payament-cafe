import type { Metadata, Viewport } from "next";
import { DM_Sans, Fraunces } from "next/font/google";
import "./globals.css";
import { ToastProvider } from "@/components/Toast";
import { PwaRegister } from "@/components/PwaRegister";

const body = DM_Sans({ subsets: ["latin"], variable: "--font-body", display: "swap" });
const display = Fraunces({ subsets: ["latin"], variable: "--font-display", display: "swap" });

export const metadata: Metadata = {
  title: { default: "Cafe Ledger", template: "%s · Cafe Ledger" },
  description: "Daily income and monthly revenue tracking for your cafe.",
  robots: { index: false, follow: false },
  manifest: "/manifest.webmanifest",
  applicationName: "Cafe Ledger",
  appleWebApp: { capable: true, title: "Cafe Ledger", statusBarStyle: "default" },
  icons: { apple: "/icons/apple-touch-icon.png" },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  themeColor: "#6f4a30",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-IN" className={`${body.variable} ${display.variable}`}>
      <body>
        <ToastProvider>{children}</ToastProvider>
        <PwaRegister />
      </body>
    </html>
  );
}
