import Link from "next/link";
import { EmptyState } from "@/components/EmptyState";
import { Icon } from "@/components/Icon";
import { PageHeader } from "@/components/PageHeader";
import { StatCard } from "@/components/StatCard";
import { TransactionList } from "@/components/TransactionList";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { dayRange, formatLongDate, formatMonthLabel, istHour, istYmd, monthBounds, rangeFromYmd } from "@/lib/dates";
import { formatINR } from "@/lib/money";
import { getSummary } from "@/lib/queries";

export const metadata = { title: "Dashboard" };

export default async function DashboardPage() {
  const user = await requireUser();
  const isAdmin = user.role === "ADMIN";

  const today = istYmd();
  const month = today.slice(0, 7);
  const { start, end } = dayRange(today);
  const { first, last } = monthBounds(month);
  const m = rangeFromYmd(first, last);

  // Every figure below is calculated by the database, not in the browser.
  const [todaySum, monthSum, recent] = await Promise.all([
    getSummary(start, end),
    isAdmin ? getSummary(m.start, m.end) : Promise.resolve(null),
    db.transaction.findMany({
      // Staff only see today's records; admins see the latest across all days
      where: isAdmin ? {} : { transactionDate: { gte: start, lt: end } },
      orderBy: { transactionDate: "desc" },
      take: 8,
      include: { createdBy: { select: { name: true } } },
    }),
  ]);

  const h = istHour();
  const greeting = h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";

  return (
    <>
      <PageHeader title={`${greeting}, ${user.name.split(" ")[0]}`} subtitle={formatLongDate(today)}>
        <Link href="/transactions/new" className="btn-primary hidden sm:inline-flex">
          <Icon name="plus" className="h-4 w-4" />
          Add Payment
        </Link>
      </PageHeader>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4">
        <StatCard
          featured
          className="col-span-2"
          label="Today's income"
          value={formatINR(todaySum.total)}
          hint={`Card ${formatINR(todaySum.byMode.CARD.total)} · Other ${formatINR(todaySum.byMode.OTHER.total)}`}
        />
        <StatCard
          label="Cash today"
          value={formatINR(todaySum.byMode.CASH.total)}
          hint={`${todaySum.byMode.CASH.count} payments`}
        />
        <StatCard
          label="UPI today"
          value={formatINR(todaySum.byMode.UPI.total)}
          hint={`${todaySum.byMode.UPI.count} payments`}
        />
        <StatCard
          label="Transactions today"
          value={String(todaySum.count)}
          className={isAdmin ? "" : "col-span-2 lg:col-span-1"}
        />
        {monthSum && (
          <StatCard
            label={`${formatMonthLabel(month)} revenue`}
            value={formatINR(monthSum.total)}
            hint={`${monthSum.count} payments this month`}
            className="col-span-2 lg:col-span-1"
          />
        )}
      </div>

      <section className="card mt-6 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-4 md:px-5">
          <h2 className="text-lg font-semibold">{isAdmin ? "Recent transactions" : "Today's transactions"}</h2>
          <Link href="/daily" className="text-sm font-semibold text-coffee-700 hover:underline">
            View all
          </Link>
        </div>
        {recent.length === 0 ? (
          <EmptyState
            title="No payments yet today"
            description="Add the first payment and it will show up here with today's totals."
            actionHref="/transactions/new"
            actionLabel="Add Payment"
          />
        ) : (
          <div className="border-t border-coffee-100">
            <TransactionList rows={recent} canManage={false} />
          </div>
        )}
      </section>
    </>
  );
}
