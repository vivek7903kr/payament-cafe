import Link from "next/link";
import { redirect } from "next/navigation";
import { DailyBarChart, ModeBars } from "@/components/Charts";
import { ExportButtons } from "@/components/ExportButtons";
import { Icon } from "@/components/Icon";
import { PageHeader } from "@/components/PageHeader";
import { StatCard } from "@/components/StatCard";
import { requireUser } from "@/lib/auth";
import {
  addMonths,
  formatLongDate,
  formatMonthLabel,
  isValidYm,
  istYmd,
  monthBounds,
  rangeFromYmd,
} from "@/lib/dates";
import { formatINR } from "@/lib/money";
import { getDailySeries, getSummary, one } from "@/lib/queries";
import type { DayRow } from "@/lib/types";

export const metadata = { title: "Monthly revenue" };

type SP = Record<string, string | string[] | undefined>;

export default async function MonthlyPage({ searchParams }: { searchParams: SP }) {
  const user = await requireUser();
  if (user.role !== "ADMIN") redirect("/dashboard");

  const today = istYmd();
  const currentMonth = today.slice(0, 7);
  const requested = one(searchParams.month);
  const month = isValidYm(requested) ? requested : currentMonth;

  const { first, last } = monthBounds(month);
  const { start, end } = rangeFromYmd(first, last);
  const [summary, series] = await Promise.all([getSummary(start, end), getDailySeries(first, last)]);

  // Average over the days that have happened so far in the month
  const daysElapsed =
    month < currentMonth ? series.length : month === currentMonth ? Number(today.slice(8)) : 0;
  const avg = daysElapsed > 0 ? summary.total / daysElapsed : 0;
  const best = series.reduce<DayRow | null>((b, d) => (d.total > (b?.total ?? 0) ? d : b), null);

  const prev = addMonths(month, -1);
  const next = addMonths(month, 1);

  return (
    <>
      <PageHeader title="Monthly revenue" subtitle={formatMonthLabel(month)}>
        <Link href={`/monthly?month=${prev}`} className="btn-secondary !px-3" aria-label="Previous month">
          <Icon name="left" className="h-4 w-4" />
        </Link>
        {next <= currentMonth ? (
          <Link href={`/monthly?month=${next}`} className="btn-secondary !px-3" aria-label="Next month">
            <Icon name="right" className="h-4 w-4" />
          </Link>
        ) : (
          <span className="btn-secondary !px-3 pointer-events-none opacity-40" aria-hidden="true">
            <Icon name="right" className="h-4 w-4" />
          </span>
        )}
      </PageHeader>

      <form method="get" className="mb-5 flex flex-wrap items-end gap-2">
        <div>
          <label htmlFor="month" className="label">Choose a month</label>
          <input
            id="month"
            type="month"
            name="month"
            defaultValue={month}
            max={currentMonth}
            placeholder="YYYY-MM"
            pattern="\d{4}-\d{2}"
            className="input"
          />
        </div>
        <button type="submit" className="btn-primary">Show month</button>
      </form>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4">
        <StatCard featured className="col-span-2" label="Total revenue" value={formatINR(summary.total)} />
        <StatCard
          label="Average per day"
          value={formatINR(avg)}
          hint={daysElapsed > 0 ? `over ${daysElapsed} days` : "no days yet"}
        />
        <StatCard label="Transactions" value={String(summary.count)} />
        <StatCard
          className="col-span-2 lg:col-span-4"
          label="Best-performing day"
          value={best ? formatINR(best.total) : "—"}
          hint={best ? `${formatLongDate(best.date)} · ${best.count} payments` : "No sales this month yet"}
        />
      </div>

      <section className="card mt-5 p-4 md:p-5">
        <h2 className="mb-3 text-lg font-semibold">Revenue by day</h2>
        <DailyBarChart data={series} />
      </section>

      <section className="card mt-5 p-4 md:p-5">
        <h2 className="mb-4 text-lg font-semibold">Payment modes</h2>
        {summary.count === 0 ? (
          <p className="py-6 text-center text-sm text-coffee-600">No payments recorded this month.</p>
        ) : (
          <ModeBars byMode={summary.byMode} total={summary.total} />
        )}
      </section>

      <section className="card mt-5 p-4 md:p-5">
        <h2 className="text-lg font-semibold">Download this month</h2>
        <p className="mb-3 mt-1 text-sm text-coffee-600">CSV files open directly in Excel and Google Sheets.</p>
        <ExportButtons from={first} to={last} />
      </section>
    </>
  );
}
