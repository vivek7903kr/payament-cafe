import { PageHeader } from "@/components/PageHeader";
import { ResetPayments } from "@/components/ResetPayments";
import { UserManager } from "@/components/UserManager";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";

export const metadata = { title: "Users" };

export default async function UsersPage() {
  const me = await requireAdmin();
  const users = await db.user.findMany({
    orderBy: [{ active: "desc" }, { role: "asc" }, { name: "asc" }],
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      active: true,
      _count: { select: { transactions: true } },
    },
  });

  const paymentCount = await db.transaction.count();

  return (
    <>
      <PageHeader title="Users" subtitle="Admins see everything. Staff can add payments and view today." />
      <UserManager
        currentUserId={me.id}
        users={users.map((u) => ({
          id: u.id,
          name: u.name,
          email: u.email,
          role: u.role,
          active: u.active,
          txCount: u._count.transactions,
        }))}
      />
      <ResetPayments count={paymentCount} />
    </>
  );
}
