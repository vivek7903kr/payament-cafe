import Link from "next/link";
import { redirect } from "next/navigation";
import { DailyBarChart, ModeBars } from "@/components/Charts";
import { EmptyState } from "@/components/EmptyState";
import { ExportButtons } from "@/components/ExportButtons";
import { PageHeader } from "@/components/PageHeader";
import { StatCard } from "@/components/StatCard";
import { requireUser } from "@/lib/auth";
import {
  addDays,
  addMonths,
  daysBetween,
  formatShortDate,
  isValidYmd,
  istYmd,
  monthBounds,
  rangeFromYmd,
} from "@/lib/dates";
import { formatINR } from "@/lib/money";
import { getDailySeries, getSummary, one } from "@/lib/queries";

export const metadata = { title: "Reports" };

type SP = Record<string, string | string[] | undefined>;

export default async function ReportsPage({ searchParams }: { searchParams: SP }) {
  const user = await requireUser();
  if (user.role !== "ADMIN") redirect("/dashboard");

  const today = istYmd();
  const monthStart = `${today.slice(0, 7)}-01`;
  const rf = one(searchParams.from);
  const rt = one(searchParams.to);
  const from = isValidYmd(rf) ? rf : monthStart;
  const to = isValidYmd(rt) ? rt : today;

  let error: string | null = null;
  if (from > to) error = "The start date must be on or before the end date.";
  else if (daysBetween(from, to) > 366) error = "Pick a range of 366 days or less.";

  const lastMonth = monthBounds(addMonths(today.slice(0, 7), -1));
  const presets = [
    { label: "Last 7 days", from: addDays(today, -6), to: today },
    { label: "Last 30 days", from: addDays(today, -29), to: today },
    { label: "This month", from: monthStart, to: today },
    { label: "Last month", from: lastMonth.first, to: lastMonth.last },
  ];

  let data: Awaited<ReturnType<typeof load>> | null = null;
  if (!error) data = await load(from, to);

  return (
    <>
      <PageHeader title="Reports" subtitle="Pick any date range to see revenue and download it." />

      <form method="get" className="card p-4 md:p-5">
        <div className="grid gap-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
          <div>
            <label htmlFor="from" className="label">From</label>
            <input id="from" type="date" name="from" defaultValue={from} max={today} className="input" />
          </div>
          <div>
            <label htmlFor="to" className="label">To</label>
            <input id="to" type="date" name="to" defaultValue={to} max={today} className="input" />
          </div>
          <button type="submit" className="btn-primary">Show report</button>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {presets.map((p) => (
            <Link
              key={p.label}
              href={`/reports?from=${p.from}&to=${p.to}`}
              className="rounded-full border border-coffee-200 px-3 py-1 text-sm font-medium text-coffee-700 hover:bg-coffee-50"
            >
              {p.label}
            </Link>
          ))}
        </div>
      </form>

      {error && (
        <p role="alert" className="mt-4 rounded-xl bg-red-50 px-4 py-3 text-sm font-medium text-red-700">
          {error}
        </p>
      )}

      {data && (
        <>
          <p className="mb-3 mt-6 text-sm text-coffee-600">
            {formatShortDate(from)} {from.slice(0, 4)} to {formatShortDate(to)} {to.slice(0, 4)} ·{" "}
            {daysBetween(from, to)} days
          </p>

          <div className="grid grid-cols-2 gap-3 lg:gap-4">
            <StatCard featured label="Total revenue" value={formatINR(data.summary.total)} />
            <StatCard label="Transactions" value={String(data.summary.count)} />
          </div>

          <section className="card mt-5 p-4 md:p-5">
            <h2 className="mb-3 text-lg font-semibold">Revenue by day</h2>
            <DailyBarChart data={data.series} />
          </section>

          <section className="card mt-5 p-4 md:p-5">
            <h2 className="mb-4 text-lg font-semibold">Revenue by payment mode</h2>
            {data.summary.count === 0 ? (
              <p className="py-6 text-center text-sm text-coffee-600">No payments in this range.</p>
            ) : (
              <ModeBars byMode={data.summary.byMode} total={data.summary.total} />
            )}
          </section>

          <section className="card mt-5 overflow-hidden">
            <h2 className="px-4 py-4 text-lg font-semibold md:px-5">Days with sales</h2>
            {data.salesDays.length === 0 ? (
              <EmptyState title="No sales in this range" description="Try a wider date range." />
            ) : (
              <div className="overflow-x-auto border-t border-coffee-100">
                <table className="w-full min-w-[34rem] text-left text-sm">
                  <thead className="text-coffee-600">
                    <tr className="border-b border-coffee-100">
                      <th className="px-4 py-3 font-medium md:px-5">Date</th>
                      <th className="px-3 py-3 text-right font-medium">Cash</th>
                      <th className="px-3 py-3 text-right font-medium">UPI</th>
                      <th className="px-3 py-3 text-right font-medium">Card</th>
                      <th className="px-3 py-3 text-right font-medium">Other</th>
                      <th className="px-3 py-3 text-right font-medium">Total</th>
                      <th className="px-4 py-3 text-right font-medium md:px-5">Txns</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-coffee-100 tabular-nums">
                    {data.salesDays.map((d) => (
                      <tr key={d.date}>
                        <td className="whitespace-nowrap px-4 py-2.5 md:px-5">{formatShortDate(d.date)}</td>
                        <td className="px-3 py-2.5 text-right">{formatINR(d.byMode.CASH)}</td>
                        <td className="px-3 py-2.5 text-right">{formatINR(d.byMode.UPI)}</td>
                        <td className="px-3 py-2.5 text-right">{formatINR(d.byMode.CARD)}</td>
                        <td className="px-3 py-2.5 text-right">{formatINR(d.byMode.OTHER)}</td>
                        <td className="px-3 py-2.5 text-right font-semibold">{formatINR(d.total)}</td>
                        <td className="px-4 py-2.5 text-right md:px-5">{d.count}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="border-t-2 border-coffee-200 font-semibold">
                    <tr>
                      <td className="px-4 py-3 md:px-5">Total</td>
                      <td className="px-3 py-3 text-right">{formatINR(data.summary.byMode.CASH.total)}</td>
                      <td className="px-3 py-3 text-right">{formatINR(data.summary.byMode.UPI.total)}</td>
                      <td className="px-3 py-3 text-right">{formatINR(data.summary.byMode.CARD.total)}</td>
                      <td className="px-3 py-3 text-right">{formatINR(data.summary.byMode.OTHER.total)}</td>
                      <td className="px-3 py-3 text-right">{formatINR(data.summary.total)}</td>
                      <td className="px-4 py-3 text-right md:px-5">{data.summary.count}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </section>

          <section className="card mt-5 p-4 md:p-5">
            <h2 className="text-lg font-semibold">Download this report</h2>
            <p className="mb-3 mt-1 text-sm text-coffee-600">CSV files open directly in Excel and Google Sheets.</p>
            <ExportButtons from={from} to={to} />
          </section>
        </>
      )}
    </>
  );
}

async function load(from: string, to: string) {
  const { start, end } = rangeFromYmd(from, to);
  const [summary, series] = await Promise.all([getSummary(start, end), getDailySeries(from, to)]);
  return { summary, series, salesDays: series.filter((d) => d.count > 0) };
}
