import { PageHeader } from "@/components/PageHeader";
import { TransactionForm } from "@/components/TransactionForm";
import { createTransaction } from "@/app/actions/transactions";
import { requireUser } from "@/lib/auth";
import { toDateTimeLocal } from "@/lib/dates";

export const metadata = { title: "Add payment" };

export default async function NewTransactionPage() {
  const user = await requireUser();
  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Add payment" subtitle="Record a sale as soon as it's paid." />
      <TransactionForm
        action={createTransaction}
        mode="create"
        staffName={user.name}
        defaults={{
          transactionDate: toDateTimeLocal(new Date()),
          amount: "",
          paymentMode: "CASH",
          orderReference: "",
          customerName: "",
          notes: "",
        }}
      />
    </div>
  );
}
