import { notFound } from "next/navigation";
import { PageHeader } from "@/components/PageHeader";
import { TransactionForm } from "@/components/TransactionForm";
import { updateTransaction } from "@/app/actions/transactions";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";
import { toDateTimeLocal } from "@/lib/dates";

export const metadata = { title: "Edit payment" };

export default async function EditTransactionPage({ params }: { params: { id: string } }) {
  await requireAdmin(); // staff are redirected away
  const tx = await db.transaction.findUnique({
    where: { id: params.id },
    include: { createdBy: { select: { name: true } } },
  });
  if (!tx) notFound();

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Edit payment" subtitle="Changes update the daily and monthly totals right away." />
      <TransactionForm
        action={updateTransaction.bind(null, tx.id)}
        mode="edit"
        staffName={tx.createdBy.name}
        defaults={{
          transactionDate: toDateTimeLocal(tx.transactionDate),
          amount: tx.amount.toFixed(2),
          paymentMode: tx.paymentMode,
          orderReference: tx.orderReference ?? "",
          customerName: tx.customerName ?? "",
          notes: tx.notes ?? "",
        }}
      />
    </div>
  );
}
