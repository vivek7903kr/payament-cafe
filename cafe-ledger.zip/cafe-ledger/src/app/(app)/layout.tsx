import { Header } from "@/components/Header";
import { InstallPrompt } from "@/components/InstallPrompt";
import { NavLinks } from "@/components/NavLinks";
import { requireUser } from "@/lib/auth";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  return (
    <div className="min-h-dvh pb-28 md:pb-10">
      <Header user={user} />
      <main className="mx-auto w-full max-w-6xl px-4 py-5 md:py-8">
        <InstallPrompt />
        {children}
      </main>
      <NavLinks role={user.role} variant="bottom" />
    </div>
  );
}
