import Link from "next/link";
import { EmptyState } from "@/components/EmptyState";
import { Icon } from "@/components/Icon";
import { PageHeader } from "@/components/PageHeader";
import { TransactionList } from "@/components/TransactionList";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { MODE_META, PAYMENT_MODES } from "@/lib/constants";
import { addDays, dayRange, formatLongDate, isValidYmd, istYmd } from "@/lib/dates";
import { formatINR } from "@/lib/money";
import { buildWhere, filtersActive, getSummary, one, parseFilters } from "@/lib/queries";

export const metadata = { title: "Daily income" };

type SP = Record<string, string | string[] | undefined>;

export default async function DailyPage({ searchParams }: { searchParams: SP }) {
  const user = await requireUser();
  const isAdmin = user.role === "ADMIN";
  const today = istYmd();

  // Staff can only look at today; admins can pick any date.
  const requested = one(searchParams.date);
  const date = isAdmin && isValidYmd(requested) ? requested : today;

  const filters = parseFilters(searchParams);
  const active = filtersActive(filters);
  const { start, end } = dayRange(date);
  const where = buildWhere(start, end, filters);

  const [summary, rows, filtered, people] = await Promise.all([
    getSummary(start, end),
    db.transaction.findMany({
      where,
      orderBy: { transactionDate: "desc" },
      take: 300,
      include: { createdBy: { select: { name: true } } },
    }),
    active
      ? db.transaction.aggregate({ where, _sum: { amount: true }, _count: { _all: true } })
      : Promise.resolve(null),
    db.user.findMany({ select: { id: true, name: true }, orderBy: { name: "asc" } }),
  ]);

  const prev = addDays(date, -1);
  const next = addDays(date, 1);

  return (
    <>
      <PageHeader title="Daily income" subtitle={formatLongDate(date)}>
        {isAdmin && (
          <>
            <Link href={`/daily?date=${prev}`} className="btn-secondary !px-3" aria-label="Previous day">
              <Icon name="left" className="h-4 w-4" />
            </Link>
            {date !== today && (
              <Link href="/daily" className="btn-secondary">
                Today
              </Link>
            )}
            {next <= today ? (
              <Link href={`/daily?date=${next}`} className="btn-secondary !px-3" aria-label="Next day">
                <Icon name="right" className="h-4 w-4" />
              </Link>
            ) : (
              <span className="btn-secondary !px-3 pointer-events-none opacity-40" aria-hidden="true">
                <Icon name="right" className="h-4 w-4" />
              </span>
            )}
          </>
        )}
        <Link href="/transactions/new" className="btn-primary">
          <Icon name="plus" className="h-4 w-4" />
          Add Payment
        </Link>
      </PageHeader>

      {!isAdmin && (
        <p className="mb-4 rounded-xl bg-coffee-100 px-4 py-2.5 text-sm text-coffee-800">
          You're viewing today's payments. Ask an admin to edit or look at earlier days.
        </p>
      )}

      {/* Day totals */}
      <section className="card p-4 md:p-5">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <div>
            <p className="text-sm text-coffee-600">Total income</p>
            <p className="font-display text-4xl font-semibold tabular-nums">{formatINR(summary.total)}</p>
          </div>
          <p className="text-sm text-coffee-600">
            {summary.count} {summary.count === 1 ? "transaction" : "transactions"}
          </p>
        </div>
        <dl className="mt-4 grid grid-cols-2 gap-2 md:grid-cols-4">
          {PAYMENT_MODES.map((m) => (
            <div key={m} className="rounded-xl bg-coffee-50 px-3 py-2.5">
              <dt className="flex items-center gap-1.5 text-sm text-coffee-700">
                <span className="h-2 w-2 rounded-full" style={{ background: MODE_META[m].color }} />
                {MODE_META[m].label}
              </dt>
              <dd className="font-semibold tabular-nums">{formatINR(summary.byMode[m].total)}</dd>
              <dd className="text-xs text-coffee-500">{summary.byMode[m].count} payments</dd>
            </div>
          ))}
        </dl>
      </section>

      {/* Filters (plain GET form – works without JavaScript) */}
      <form method="get" className="card mt-4 p-4 md:p-5">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
          {isAdmin && (
            <div>
              <label htmlFor="f-date" className="label">Date</label>
              <input id="f-date" type="date" name="date" defaultValue={date} max={today} className="input" />
            </div>
          )}
          <div className="lg:col-span-2">
            <label htmlFor="f-q" className="label">Search</label>
            <input
              id="f-q"
              name="q"
              defaultValue={filters.q ?? ""}
              placeholder="Order no., customer or note"
              className="input"
            />
          </div>
          <div>
            <label htmlFor="f-mode" className="label">Payment mode</label>
            <select id="f-mode" name="mode" defaultValue={filters.mode ?? ""} className="input">
              <option value="">All modes</option>
              {PAYMENT_MODES.map((m) => (
                <option key={m} value={m}>{MODE_META[m].label}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="f-staff" className="label">Staff member</label>
            <select id="f-staff" name="staff" defaultValue={filters.staffId ?? ""} className="input">
              <option value="">Everyone</option>
              {people.map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label htmlFor="f-min" className="label">Min ₹</label>
              <input id="f-min" name="min" inputMode="decimal" defaultValue={filters.min ?? ""} className="input" />
            </div>
            <div>
              <label htmlFor="f-max" className="label">Max ₹</label>
              <input id="f-max" name="max" inputMode="decimal" defaultValue={filters.max ?? ""} className="input" />
            </div>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <button type="submit" className="btn-primary">
            <Icon name="search" className="h-4 w-4" />
            Apply filters
          </button>
          {active && (
            <Link href={isAdmin ? `/daily?date=${date}` : "/daily"} className="btn-secondary">
              Clear filters
            </Link>
          )}
        </div>
      </form>

      {/* Transactions */}
      <section className="card mt-4 overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-4 md:px-5">
          <h2 className="text-lg font-semibold">Transactions</h2>
          {filtered && (
            <p className="text-sm text-coffee-600">
              {filtered._count._all} matching · {formatINR(filtered._sum.amount)}
            </p>
          )}
        </div>
        {rows.length === 0 ? (
          <EmptyState
            title={active ? "No payments match these filters" : "No payments on this day"}
            description={
              active
                ? "Try a different search or clear the filters."
                : "Payments added for this day will be listed here."
            }
            actionHref={active ? undefined : "/transactions/new"}
            actionLabel={active ? undefined : "Add Payment"}
          />
        ) : (
          <div className="border-t border-coffee-100">
            <TransactionList rows={rows} canManage={isAdmin} />
            {rows.length === 300 && (
              <p className="border-t border-coffee-100 px-5 py-3 text-sm text-coffee-600">
                Showing the latest 300 payments. Narrow the filters to see others.
              </p>
            )}
          </div>
        )}
      </section>
    </>
  );
}
