"use client";

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="card mx-auto mt-10 max-w-md p-8 text-center">
      <h1 className="text-xl font-semibold">Something went wrong</h1>
      <p className="mt-2 text-sm text-coffee-600">
        We couldn't load this page. Check your connection and try again.
      </p>
      {error.digest && <p className="mt-2 text-xs text-coffee-400">Reference: {error.digest}</p>}
      <button onClick={reset} className="btn-primary mt-5">
        Try again
      </button>
    </div>
  );
}
