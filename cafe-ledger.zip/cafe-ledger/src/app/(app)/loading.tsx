export default function Loading() {
  return (
    <div className="animate-pulse space-y-5" aria-busy="true" aria-label="Loading">
      <div className="h-8 w-48 rounded-lg bg-coffee-100" />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <div className="col-span-2 h-32 rounded-2xl bg-coffee-100" />
        <div className="h-28 rounded-2xl bg-coffee-100" />
        <div className="h-28 rounded-2xl bg-coffee-100" />
      </div>
      <div className="h-64 rounded-2xl bg-coffee-100" />
    </div>
  );
}
