import Link from "next/link";

export default function NotFound() {
  return (
    <main className="grid min-h-dvh place-items-center px-4 text-center">
      <div>
        <h1 className="text-3xl font-semibold">Page not found</h1>
        <p className="mt-2 text-coffee-600">That page doesn't exist or has been removed.</p>
        <Link href="/dashboard" className="btn-primary mt-5">
          Back to dashboard
        </Link>
      </div>
    </main>
  );
}
