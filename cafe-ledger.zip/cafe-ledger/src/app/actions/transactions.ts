"use server";

import bcrypt from "bcryptjs";
import { revalidatePath } from "next/cache";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { formatINR } from "@/lib/money";
import { istYmd } from "@/lib/dates";
import {
  TRANSACTION_KEYS,
  flattenErrors,
  formToObject,
  transactionSchema,
} from "@/lib/validation";
import type { ActionResult, FormState } from "@/lib/types";

function refresh() {
  for (const p of ["/dashboard", "/daily", "/monthly", "/reports"]) revalidatePath(p);
}

const expired = (): FormState => ({
  ok: false,
  message: "Your session has expired. Please sign in again.",
  ts: Date.now(),
});

/** Any signed-in user (admin or staff) can record a payment. */
export async function createTransaction(_prev: FormState, fd: FormData): Promise<FormState> {
  const session = await getSession();
  if (!session) return expired();

  const parsed = transactionSchema.safeParse(formToObject(fd, TRANSACTION_KEYS));
  if (!parsed.success) {
    return {
      ok: false,
      message: "Please fix the highlighted fields.",
      errors: flattenErrors(parsed.error),
      ts: Date.now(),
    };
  }
  const d = parsed.data;

  try {
    await db.transaction.create({
      data: {
        transactionDate: d.transactionDate,
        amount: d.amount,
        paymentMode: d.paymentMode,
        orderReference: d.orderReference,
        customerName: d.customerName,
        notes: d.notes,
        createdByUserId: session.id, // always the logged-in user, never client-supplied
      },
    });
  } catch (e) {
    console.error("createTransaction failed", e);
    return { ok: false, message: "Couldn't save the payment. Try again.", ts: Date.now() };
  }

  refresh();
  return { ok: true, message: `Payment of ${formatINR(d.amount)} added`, ts: Date.now() };
}

/** Admin only. */
export async function updateTransaction(
  id: string,
  _prev: FormState,
  fd: FormData
): Promise<FormState> {
  const session = await getSession();
  if (!session) return expired();
  if (session.role !== "ADMIN") {
    return { ok: false, message: "Only admins can edit payments.", ts: Date.now() };
  }

  const parsed = transactionSchema.safeParse(formToObject(fd, TRANSACTION_KEYS));
  if (!parsed.success) {
    return {
      ok: false,
      message: "Please fix the highlighted fields.",
      errors: flattenErrors(parsed.error),
      ts: Date.now(),
    };
  }
  const d = parsed.data;

  try {
    await db.transaction.update({
      where: { id },
      data: {
        transactionDate: d.transactionDate,
        amount: d.amount,
        paymentMode: d.paymentMode,
        orderReference: d.orderReference,
        customerName: d.customerName,
        notes: d.notes,
      },
    });
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2025") {
      return { ok: false, message: "This payment no longer exists.", ts: Date.now() };
    }
    console.error("updateTransaction failed", e);
    return { ok: false, message: "Couldn't save changes. Try again.", ts: Date.now() };
  }

  refresh();
  return {
    ok: true,
    message: "Changes saved",
    redirectTo: `/daily?date=${istYmd(d.transactionDate)}`,
    ts: Date.now(),
  };
}

/** Admin only. The UI asks for confirmation before calling this. */
export async function deleteTransaction(id: string): Promise<ActionResult> {
  const session = await getSession();
  if (!session) return { ok: false, message: "Your session has expired. Please sign in again." };
  if (session.role !== "ADMIN") return { ok: false, message: "Only admins can delete payments." };

  try {
    const res = await db.transaction.deleteMany({ where: { id } });
    if (res.count === 0) return { ok: false, message: "This payment was already deleted." };
  } catch (e) {
    console.error("deleteTransaction failed", e);
    return { ok: false, message: "Couldn't delete the payment. Try again." };
  }
  refresh();
  return { ok: true, message: "Payment deleted" };
}

/**
 * Admin only. Permanently deletes EVERY payment so the cafe can start fresh.
 * Users and logins are kept. Requires typing RESET and re-entering the admin's password.
 */
export async function resetAllPayments(_prev: FormState, fd: FormData): Promise<FormState> {
  const session = await getSession();
  if (!session) return expired();
  if (session.role !== "ADMIN") {
    return { ok: false, message: "Only admins can reset payments.", ts: Date.now() };
  }

  const phrase = String(fd.get("confirm") ?? "").trim();
  const password = String(fd.get("password") ?? "");

  if (phrase !== "RESET") {
    return {
      ok: false,
      message: "Type RESET in capital letters to confirm.",
      errors: { confirm: "Type RESET exactly" },
      ts: Date.now(),
    };
  }

  const me = await db.user.findUnique({
    where: { id: session.id },
    select: { passwordHash: true },
  });
  if (!me || !password || !(await bcrypt.compare(password, me.passwordHash))) {
    return {
      ok: false,
      message: "Incorrect password.",
      errors: { password: "Incorrect password" },
      ts: Date.now(),
    };
  }

  try {
    const res = await db.transaction.deleteMany();
    console.warn(`[audit] ${session.email} reset all payments (${res.count} deleted)`);
    refresh();
    revalidatePath("/users");
    return {
      ok: true,
      message: `All ${res.count} payments deleted. You're starting fresh.`,
      ts: Date.now(),
    };
  } catch (e) {
    console.error("resetAllPayments failed", e);
    return { ok: false, message: "Couldn't reset the payments. Try again.", ts: Date.now() };
  }
}
