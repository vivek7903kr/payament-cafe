"use server";

import bcrypt from "bcryptjs";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { createSession, destroySession } from "@/lib/auth";
import type { FormState } from "@/lib/types";

// Best-effort brute-force protection (per server instance).
const attempts = new Map<string, { count: number; resetAt: number }>();
const MAX_ATTEMPTS = 8;
const WINDOW_MS = 15 * 60_000;

let dummyHash: string | null = null;
const getDummyHash = () => (dummyHash ??= bcrypt.hashSync("not-a-real-password", 12));

export async function loginAction(_prev: FormState, fd: FormData): Promise<FormState> {
  const email = String(fd.get("email") ?? "").trim().toLowerCase();
  const password = String(fd.get("password") ?? "");
  if (!email || !password) {
    return { ok: false, message: "Enter your email and password.", ts: Date.now() };
  }

  const now = Date.now();
  const rec = attempts.get(email);
  if (rec && rec.resetAt > now && rec.count >= MAX_ATTEMPTS) {
    return {
      ok: false,
      message: "Too many failed attempts. Wait a few minutes and try again.",
      ts: now,
    };
  }

  const user = await db.user.findUnique({ where: { email } });
  // Always run a bcrypt comparison so response time doesn't reveal if the email exists.
  const match = await bcrypt.compare(password, user?.passwordHash ?? getDummyHash());

  if (!user || !match || !user.active) {
    const fresh = rec && rec.resetAt > now ? rec : { count: 0, resetAt: now + WINDOW_MS };
    fresh.count += 1;
    attempts.set(email, fresh);
    return { ok: false, message: "Incorrect email or password.", ts: now };
  }

  attempts.delete(email);
  await createSession(user);
  redirect("/dashboard");
}

export async function logoutAction(): Promise<void> {
  await destroySession();
  redirect("/login");
}
