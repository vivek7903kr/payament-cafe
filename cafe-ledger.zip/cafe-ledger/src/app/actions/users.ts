"use server";

import bcrypt from "bcryptjs";
import { z } from "zod";
import { revalidatePath } from "next/cache";
import { Prisma, type Role } from "@prisma/client";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { flattenErrors, formToObject } from "@/lib/validation";
import type { ActionResult, FormState } from "@/lib/types";

async function adminOnly() {
  const s = await getSession();
  return s && s.role === "ADMIN" ? s : null;
}

const passwordRule = z
  .string()
  .min(8, "Use at least 8 characters")
  .max(128, "Keep the password under 128 characters");

const createSchema = z.object({
  name: z.string().trim().min(2, "Enter a name").max(80),
  email: z.string().trim().toLowerCase().email("Enter a valid email").max(120),
  password: passwordRule,
  role: z.enum(["ADMIN", "STAFF"]),
});

export async function createUser(_prev: FormState, fd: FormData): Promise<FormState> {
  if (!(await adminOnly())) {
    return { ok: false, message: "Only admins can manage users.", ts: Date.now() };
  }
  const parsed = createSchema.safeParse(formToObject(fd, ["name", "email", "password", "role"]));
  if (!parsed.success) {
    return {
      ok: false,
      message: "Please fix the highlighted fields.",
      errors: flattenErrors(parsed.error),
      ts: Date.now(),
    };
  }
  const { name, email, password, role } = parsed.data;
  try {
    await db.user.create({
      data: { name, email, role, passwordHash: await bcrypt.hash(password, 12) },
    });
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
      return {
        ok: false,
        message: "That email is already in use.",
        errors: { email: "That email is already in use" },
        ts: Date.now(),
      };
    }
    console.error("createUser failed", e);
    return { ok: false, message: "Couldn't create the user.", ts: Date.now() };
  }
  revalidatePath("/users");
  return { ok: true, message: `${name} can now sign in`, ts: Date.now() };
}

export async function setUserRole(id: string, role: Role): Promise<ActionResult> {
  const s = await adminOnly();
  if (!s) return { ok: false, message: "Only admins can manage users." };
  if (id === s.id) return { ok: false, message: "You can't change your own role." };
  if (role !== "ADMIN" && role !== "STAFF") return { ok: false, message: "Invalid role." };
  await db.user.update({ where: { id }, data: { role } });
  revalidatePath("/users");
  return { ok: true, message: "Role updated" };
}

export async function setUserActive(id: string, active: boolean): Promise<ActionResult> {
  const s = await adminOnly();
  if (!s) return { ok: false, message: "Only admins can manage users." };
  if (id === s.id) return { ok: false, message: "You can't deactivate your own account." };
  await db.user.update({ where: { id }, data: { active } });
  revalidatePath("/users");
  return { ok: true, message: active ? "User re-activated" : "User deactivated" };
}

export async function resetUserPassword(id: string, password: string): Promise<ActionResult> {
  const s = await adminOnly();
  if (!s) return { ok: false, message: "Only admins can manage users." };
  const parsed = passwordRule.safeParse(password);
  if (!parsed.success) return { ok: false, message: parsed.error.issues[0].message };
  await db.user.update({
    where: { id },
    data: { passwordHash: await bcrypt.hash(parsed.data, 12) },
  });
  return { ok: true, message: "Password updated" };
}
