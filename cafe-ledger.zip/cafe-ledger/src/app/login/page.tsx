import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { Icon } from "@/components/Icon";
import { LoginForm } from "./LoginForm";

export const metadata = { title: "Sign in" };

export default async function LoginPage() {
  if (await getSession()) redirect("/dashboard");

  return (
    <main className="grid min-h-dvh place-items-center px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="mb-6 flex flex-col items-center text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-coffee-700 text-white shadow-card">
            <Icon name="cup" className="h-7 w-7" />
          </span>
          <h1 className="mt-4 text-3xl font-semibold text-coffee-900">Cafe Ledger</h1>
          <p className="mt-1 text-sm text-coffee-600">Sign in to record and review payments.</p>
        </div>
        <LoginForm />
      </div>
    </main>
  );
}
