type MoneyInput = number | string | { toString(): string } | null | undefined;

const inr = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const compact = new Intl.NumberFormat("en-IN", {
  notation: "compact",
  maximumFractionDigits: 1,
});

/** ₹1,23,456.00 */
export function formatINR(v: MoneyInput): string {
  return inr.format(Number(v == null ? 0 : String(v)));
}

/** ₹1.2K / ₹3.4L – for chart axes */
export function formatINRCompact(v: number): string {
  return `₹${compact.format(v)}`;
}
