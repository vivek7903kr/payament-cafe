import { z } from "zod";
import { PAYMENT_MODES } from "./constants";
import { parseDateTimeLocal } from "./dates";

const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max, `Keep this under ${max} characters`)
    .transform((v) => (v === "" ? null : v));

export const transactionSchema = z.object({
  transactionDate: z
    .string()
    .trim()
    .refine((v) => parseDateTimeLocal(v) !== null, "Enter a valid date and time")
    .transform((v) => parseDateTimeLocal(v)!)
    .refine(
      (d) => d.getTime() <= Date.now() + 5 * 60_000,
      "The date and time can't be in the future"
    ),
  amount: z
    .string()
    .trim()
    .regex(/^\d{1,9}(\.\d{1,2})?$/, "Enter an amount like 250 or 250.50")
    .refine((v) => Number(v) > 0, "Amount must be more than ₹0"),
  paymentMode: z.enum(PAYMENT_MODES, {
    errorMap: () => ({ message: "Choose a payment mode" }),
  }),
  orderReference: optionalText(60),
  customerName: optionalText(80),
  notes: optionalText(500),
});

export const TRANSACTION_KEYS = [
  "transactionDate",
  "amount",
  "paymentMode",
  "orderReference",
  "customerName",
  "notes",
];

export function formToObject(fd: FormData, keys: string[]) {
  const o: Record<string, string> = {};
  for (const k of keys) {
    const v = fd.get(k);
    o[k] = typeof v === "string" ? v : "";
  }
  return o;
}

export function flattenErrors(err: z.ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of err.issues) {
    const k = String(issue.path[0] ?? "form");
    if (!out[k]) out[k] = issue.message;
  }
  return out;
}
