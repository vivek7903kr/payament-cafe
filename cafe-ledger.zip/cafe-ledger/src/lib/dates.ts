// All business dates are India Standard Time (UTC+05:30, no daylight saving).
// Timestamps are stored as UTC instants in Postgres (timestamptz); day / month
// boundaries are always computed in IST.

export const TZ = "Asia/Kolkata";
const OFFSET = "+05:30";
const DAY_MS = 86_400_000;

export function isValidYmd(s: unknown): s is string {
  if (typeof s !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}

export function isValidYm(s: unknown): s is string {
  if (typeof s !== "string" || !/^\d{4}-\d{2}$/.test(s)) return false;
  const m = Number(s.slice(5));
  return m >= 1 && m <= 12;
}

/** Today's (or the given instant's) date in IST as YYYY-MM-DD */
export function istYmd(d: Date = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(d);
}

export const istMonth = (d: Date = new Date()) => istYmd(d).slice(0, 7);

export function istHour(d: Date = new Date()): number {
  const h = new Intl.DateTimeFormat("en-GB", {
    timeZone: TZ,
    hour: "2-digit",
    hour12: false,
  }).format(d);
  return Number(h) % 24;
}

/** [start, end) instants for one IST calendar day */
export function dayRange(ymd: string) {
  const start = new Date(`${ymd}T00:00:00${OFFSET}`);
  return { start, end: new Date(start.getTime() + DAY_MS) };
}

/** [start, end) instants covering from..to inclusive (IST days) */
export function rangeFromYmd(from: string, to: string) {
  return { start: dayRange(from).start, end: dayRange(to).end };
}

export function addDays(ymd: string, n: number): string {
  const d = new Date(`${ymd}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

export function addMonths(ym: string, n: number): string {
  const [y, m] = ym.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1 + n, 1)).toISOString().slice(0, 7);
}

export function monthBounds(ym: string) {
  return { first: `${ym}-01`, last: addDays(`${addMonths(ym, 1)}-01`, -1) };
}

export function daysBetween(from: string, to: string): number {
  return (
    Math.round(
      (Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / DAY_MS
    ) + 1
  );
}

export function eachDay(from: string, to: string): string[] {
  const n = daysBetween(from, to);
  if (n < 1 || n > 400) throw new Error("Invalid date range");
  return Array.from({ length: n }, (_, i) => addDays(from, i));
}

/** Value for <input type="datetime-local"> in IST (YYYY-MM-DDTHH:mm) */
export function toDateTimeLocal(d: Date): string {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(d);
  const g = (t: string) => parts.find((p) => p.type === t)!.value;
  return `${g("year")}-${g("month")}-${g("day")}T${g("hour")}:${g("minute")}`;
}

/** Parse a datetime-local string, interpreting it as IST */
export function parseDateTimeLocal(s: string): Date | null {
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?$/.test(s)) return null;
  const full = s.length === 16 ? `${s}:00` : s;
  const d = new Date(`${full}${OFFSET}`);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function formatDateTime(d: Date): string {
  return new Intl.DateTimeFormat("en-IN", {
    timeZone: TZ,
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }).format(d);
}

export function formatTime(d: Date): string {
  return new Intl.DateTimeFormat("en-IN", {
    timeZone: TZ,
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }).format(d);
}

const utcFmt = (opts: Intl.DateTimeFormatOptions) =>
  new Intl.DateTimeFormat("en-IN", { ...opts, timeZone: "UTC" });

export function formatLongDate(ymd: string): string {
  return utcFmt({
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(`${ymd}T00:00:00Z`));
}

export function formatShortDate(ymd: string): string {
  return utcFmt({ day: "numeric", month: "short" }).format(
    new Date(`${ymd}T00:00:00Z`)
  );
}

export function formatMonthLabel(ym: string): string {
  return utcFmt({ month: "long", year: "numeric" }).format(
    new Date(`${ym}-01T00:00:00Z`)
  );
}
