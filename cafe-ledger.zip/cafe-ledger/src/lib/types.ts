import type { PaymentMode } from "@prisma/client";

export type FormState = {
  ok: boolean;
  message?: string;
  errors?: Record<string, string>;
  redirectTo?: string;
  /** changes on every submit so effects can react to repeated identical results */
  ts?: number;
};

export type ActionResult = { ok: boolean; message: string };

export type ModeTotals = Record<PaymentMode, { total: number; count: number }>;

export interface Summary {
  total: number;
  count: number;
  byMode: ModeTotals;
}

export interface DayRow {
  date: string; // YYYY-MM-DD (IST)
  total: number;
  count: number;
  byMode: Record<PaymentMode, number>;
}
