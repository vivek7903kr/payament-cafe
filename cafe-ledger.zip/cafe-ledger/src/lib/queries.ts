import "server-only";
import { Prisma, type PaymentMode } from "@prisma/client";
import { db } from "./db";
import { PAYMENT_MODES } from "./constants";
import { eachDay, rangeFromYmd } from "./dates";
import type { DayRow, ModeTotals, Summary } from "./types";

const emptyModes = (): ModeTotals => ({
  CASH: { total: 0, count: 0 },
  UPI: { total: 0, count: 0 },
  CARD: { total: 0, count: 0 },
  OTHER: { total: 0, count: 0 },
});

/** Totals + per-mode breakdown for [start, end), computed by the database. */
export async function getSummary(start: Date, end: Date): Promise<Summary> {
  const rows = await db.transaction.groupBy({
    by: ["paymentMode"],
    where: { transactionDate: { gte: start, lt: end } },
    _sum: { amount: true },
    _count: { _all: true },
  });

  const byMode = emptyModes();
  let total = new Prisma.Decimal(0);
  let count = 0;
  for (const r of rows) {
    const sum = r._sum.amount ?? new Prisma.Decimal(0);
    byMode[r.paymentMode] = { total: sum.toNumber(), count: r._count._all };
    total = total.plus(sum);
    count += r._count._all;
  }
  return { total: total.toNumber(), count, byMode };
}

/** One row per IST calendar day from..to (inclusive), zero-filled. */
export async function getDailySeries(from: string, to: string): Promise<DayRow[]> {
  const days = eachDay(from, to);
  const { start, end } = rangeFromYmd(from, to);
  const startIso = start.toISOString();
  const endIso = end.toISOString();

  const rows = await db.$queryRaw<
    { day: string; mode: PaymentMode; total: string; count: number }[]
  >`
    SELECT to_char(transaction_date AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD') AS day,
           payment_mode::text AS mode,
           SUM(amount)::text AS total,
           COUNT(*)::int AS count
    FROM transactions
    WHERE transaction_date >= ${startIso}::timestamptz
      AND transaction_date <  ${endIso}::timestamptz
    GROUP BY 1, 2`;

  const map = new Map<string, DayRow>(
    days.map((d) => [
      d,
      { date: d, total: 0, count: 0, byMode: { CASH: 0, UPI: 0, CARD: 0, OTHER: 0 } },
    ])
  );
  for (const r of rows) {
    const row = map.get(r.day);
    if (!row) continue;
    const t = Number(r.total);
    row.byMode[r.mode] = t;
    row.total = Math.round((row.total + t) * 100) / 100;
    row.count += r.count;
  }
  return days.map((d) => map.get(d)!);
}

// ---------- Daily page filters ----------

export interface DailyFilters {
  mode?: PaymentMode;
  staffId?: string;
  min?: string;
  max?: string;
  q?: string;
}

type SP = Record<string, string | string[] | undefined>;
export const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);

export function parseFilters(sp: SP): DailyFilters {
  const f: DailyFilters = {};
  const mode = one(sp.mode);
  if (mode && (PAYMENT_MODES as readonly string[]).includes(mode)) f.mode = mode as PaymentMode;
  const staff = one(sp.staff);
  if (staff && /^[a-z0-9]{10,40}$/i.test(staff)) f.staffId = staff;
  const amt = /^\d{1,9}(\.\d{1,2})?$/;
  const min = one(sp.min)?.trim();
  const max = one(sp.max)?.trim();
  if (min && amt.test(min)) f.min = min;
  if (max && amt.test(max)) f.max = max;
  const q = one(sp.q)?.trim().slice(0, 80);
  if (q) f.q = q;
  return f;
}

export const filtersActive = (f: DailyFilters) => Object.keys(f).length > 0;

export function buildWhere(
  start: Date,
  end: Date,
  f: DailyFilters
): Prisma.TransactionWhereInput {
  const where: Prisma.TransactionWhereInput = {
    transactionDate: { gte: start, lt: end },
  };
  if (f.mode) where.paymentMode = f.mode;
  if (f.staffId) where.createdByUserId = f.staffId;
  if (f.min || f.max) {
    where.amount = { ...(f.min ? { gte: f.min } : {}), ...(f.max ? { lte: f.max } : {}) };
  }
  if (f.q) {
    where.OR = [
      { orderReference: { contains: f.q, mode: "insensitive" } },
      { customerName: { contains: f.q, mode: "insensitive" } },
      { notes: { contains: f.q, mode: "insensitive" } },
    ];
  }
  return where;
}
