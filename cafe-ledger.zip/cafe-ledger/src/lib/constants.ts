// No imports here: this file is also used by the Edge middleware.
export const SESSION_COOKIE = "cafe_session";

export const PAYMENT_MODES = ["CASH", "UPI", "CARD", "OTHER"] as const;
export type PaymentModeKey = (typeof PAYMENT_MODES)[number];

export const MODE_META: Record<
  PaymentModeKey,
  { label: string; color: string; badge: string }
> = {
  CASH: { label: "Cash", color: "#b7791f", badge: "bg-amber-100 text-amber-800" },
  UPI: { label: "UPI", color: "#2f7d6d", badge: "bg-teal-100 text-teal-800" },
  CARD: { label: "Card", color: "#5b6aa8", badge: "bg-indigo-100 text-indigo-800" },
  OTHER: { label: "Other", color: "#8a817c", badge: "bg-stone-200 text-stone-700" },
};
