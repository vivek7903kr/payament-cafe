import { MODE_META, type PaymentModeKey } from "@/lib/constants";

export function ModeBadge({ mode }: { mode: PaymentModeKey }) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${MODE_META[mode].badge}`}
    >
      {MODE_META[mode].label}
    </span>
  );
}
