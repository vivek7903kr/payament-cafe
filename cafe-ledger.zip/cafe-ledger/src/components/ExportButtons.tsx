import { Icon } from "./Icon";

export function ExportButtons({ from, to }: { from: string; to: string }) {
  const qs = `from=${from}&to=${to}`;
  return (
    <div className="flex flex-wrap gap-2">
      <a href={`/api/export?kind=transactions&${qs}`} className="btn-secondary" download>
        <Icon name="download" className="h-4 w-4" />
        All payments (CSV)
      </a>
      <a href={`/api/export?kind=daily&${qs}`} className="btn-secondary" download>
        <Icon name="download" className="h-4 w-4" />
        Daily totals (CSV)
      </a>
    </div>
  );
}
