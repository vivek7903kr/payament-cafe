"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { useFormState } from "react-dom";
import { createUser, resetUserPassword, setUserActive, setUserRole } from "@/app/actions/users";
import type { ActionResult, FormState } from "@/lib/types";
import { SubmitButton } from "./SubmitButton";
import { useToast } from "./Toast";

export type UserRowData = {
  id: string;
  name: string;
  email: string;
  role: "ADMIN" | "STAFF";
  active: boolean;
  txCount: number;
};

export function UserManager({ users, currentUserId }: { users: UserRowData[]; currentUserId: string }) {
  const [state, action] = useFormState(createUser, { ok: false } as FormState);
  const formRef = useRef<HTMLFormElement>(null);
  const toast = useToast();
  const errors = state.errors ?? {};

  useEffect(() => {
    if (!state.ts) return;
    if (state.ok) {
      toast.success(state.message ?? "User created");
      formRef.current?.reset();
    } else if (state.message) toast.error(state.message);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_22rem]">
      <section className="card divide-y divide-coffee-100">
        {users.map((u) => (
          <UserRow key={u.id} u={u} isSelf={u.id === currentUserId} />
        ))}
      </section>

      <section className="card h-fit p-5">
        <h2 className="text-lg font-semibold">Add a user</h2>
        <form ref={formRef} action={action} className="mt-4 space-y-4" noValidate>
          <div>
            <label htmlFor="u-name" className="label">Name</label>
            <input id="u-name" name="name" className="input" autoComplete="off" />
            {errors.name && <p className="field-error">{errors.name}</p>}
          </div>
          <div>
            <label htmlFor="u-email" className="label">Email</label>
            <input id="u-email" name="email" type="email" className="input" autoComplete="off" />
            {errors.email && <p className="field-error">{errors.email}</p>}
          </div>
          <div>
            <label htmlFor="u-password" className="label">Temporary password</label>
            <input id="u-password" name="password" type="text" className="input" autoComplete="off" />
            {errors.password ? (
              <p className="field-error">{errors.password}</p>
            ) : (
              <p className="mt-1 text-xs text-coffee-500">At least 8 characters. Share it privately.</p>
            )}
          </div>
          <div>
            <label htmlFor="u-role" className="label">Role</label>
            <select id="u-role" name="role" defaultValue="STAFF" className="input">
              <option value="STAFF">Staff – add payments, view today</option>
              <option value="ADMIN">Admin – full access</option>
            </select>
          </div>
          <SubmitButton className="btn-primary w-full" pendingLabel="Adding…">
            Add user
          </SubmitButton>
        </form>
      </section>
    </div>
  );
}

function UserRow({ u, isSelf }: { u: UserRowData; isSelf: boolean }) {
  const [pending, start] = useTransition();
  const [showPw, setShowPw] = useState(false);
  const [pw, setPw] = useState("");
  const toast = useToast();

  function run(fn: () => Promise<ActionResult>, after?: () => void) {
    start(async () => {
      const r = await fn();
      if (r.ok) {
        toast.success(r.message);
        after?.();
      } else toast.error(r.message);
    });
  }

  return (
    <div className={`p-4 md:p-5 ${u.active ? "" : "bg-coffee-50/70"}`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-semibold text-coffee-900">
            {u.name}
            {isSelf && <span className="ml-2 text-xs font-normal text-coffee-500">(you)</span>}
            {!u.active && (
              <span className="ml-2 rounded-full bg-stone-200 px-2 py-0.5 text-xs font-medium text-stone-700">
                Deactivated
              </span>
            )}
          </p>
          <p className="truncate text-sm text-coffee-600">{u.email}</p>
          <p className="mt-0.5 text-xs text-coffee-500">
            {u.txCount} {u.txCount === 1 ? "payment" : "payments"} recorded
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            aria-label={`Role for ${u.name}`}
            value={u.role}
            disabled={isSelf || pending}
            onChange={(e) => run(() => setUserRole(u.id, e.target.value as "ADMIN" | "STAFF"))}
            className="rounded-lg border border-coffee-200 bg-white px-2.5 py-2 text-sm disabled:opacity-60"
          >
            <option value="STAFF">Staff</option>
            <option value="ADMIN">Admin</option>
          </select>
          <button type="button" className="btn-secondary !py-2" onClick={() => setShowPw((s) => !s)}>
            Reset password
          </button>
          {!isSelf && (
            <button
              type="button"
              disabled={pending}
              className="btn-secondary !py-2"
              onClick={() => run(() => setUserActive(u.id, !u.active))}
            >
              {u.active ? "Deactivate" : "Re-activate"}
            </button>
          )}
        </div>
      </div>

      {showPw && (
        <div className="mt-3 flex flex-wrap gap-2">
          <input
            type="text"
            value={pw}
            onChange={(e) => setPw(e.target.value)}
            placeholder="New password (8+ characters)"
            aria-label={`New password for ${u.name}`}
            autoComplete="off"
            className="input max-w-xs !py-2"
          />
          <button
            type="button"
            disabled={pending}
            className="btn-primary !py-2"
            onClick={() =>
              run(() => resetUserPassword(u.id, pw), () => {
                setPw("");
                setShowPw(false);
              })
            }
          >
            Save password
          </button>
        </div>
      )}
    </div>
  );
}
