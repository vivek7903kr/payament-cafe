import Link from "next/link";
import { logoutAction } from "@/app/actions/auth";
import type { SessionUser } from "@/lib/auth";
import { Icon } from "./Icon";
import { NavLinks } from "./NavLinks";

export function Header({ user }: { user: SessionUser }) {
  return (
    <header className="sticky top-0 z-30 border-b border-coffee-100 bg-cream/90 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-6xl items-center gap-3 px-4 md:h-16">
        <Link
          href="/dashboard"
          className="flex items-center gap-2 font-display text-lg font-semibold text-coffee-800"
        >
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-coffee-700 text-white">
            <Icon name="cup" className="h-4 w-4" />
          </span>
          Cafe Ledger
        </Link>
        <NavLinks role={user.role} variant="top" />

        <div className="ml-auto flex items-center gap-2">
          <div className="mr-1 hidden text-right text-xs leading-tight sm:block">
            <div className="font-semibold text-coffee-900">{user.name}</div>
            <div className="text-coffee-500">{user.role === "ADMIN" ? "Admin" : "Staff"}</div>
          </div>
          <Link href="/transactions/new" className="btn-primary hidden md:inline-flex">
            <Icon name="plus" className="h-4 w-4" />
            Add Payment
          </Link>
          {user.role === "ADMIN" && (
            <Link href="/users" className="btn-secondary !px-3" aria-label="Manage users">
              <Icon name="users" className="h-4 w-4" />
              <span className="hidden lg:inline">Users</span>
            </Link>
          )}
          <form action={logoutAction}>
            <button type="submit" className="btn-secondary !px-3" aria-label="Sign out">
              <Icon name="logout" className="h-4 w-4" />
              <span className="hidden lg:inline">Sign out</span>
            </button>
          </form>
        </div>
      </div>
    </header>
  );
}
