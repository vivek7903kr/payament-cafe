import Link from "next/link";
import { Icon } from "./Icon";

export function EmptyState({
  title,
  description,
  actionHref,
  actionLabel,
}: {
  title: string;
  description?: string;
  actionHref?: string;
  actionLabel?: string;
}) {
  return (
    <div className="flex flex-col items-center px-6 py-12 text-center">
      <span className="grid h-14 w-14 place-items-center rounded-full bg-coffee-100 text-coffee-600">
        <Icon name="cup" className="h-7 w-7" />
      </span>
      <h3 className="mt-4 text-lg font-semibold text-coffee-900">{title}</h3>
      {description && <p className="mt-1 max-w-sm text-sm text-coffee-600">{description}</p>}
      {actionHref && actionLabel && (
        <Link href={actionHref} className="btn-primary mt-5">
          {actionLabel}
        </Link>
      )}
    </div>
  );
}
