"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Icon, type IconName } from "./Icon";

type Item = { href: string; label: string; icon: IconName };

export function NavLinks({ role, variant }: { role: "ADMIN" | "STAFF"; variant: "top" | "bottom" }) {
  const pathname = usePathname();
  const items: Item[] = [
    { href: "/dashboard", label: "Home", icon: "home" },
    { href: "/daily", label: "Daily", icon: "calendar" },
    ...(role === "ADMIN"
      ? ([
          { href: "/monthly", label: "Monthly", icon: "chart" },
          { href: "/reports", label: "Reports", icon: "report" },
        ] as Item[])
      : []),
  ];
  const active = (href: string) => pathname === href || pathname.startsWith(href + "/");

  if (variant === "top") {
    return (
      <nav className="ml-4 hidden items-center gap-1 md:flex" aria-label="Main">
        {items.map((it) => (
          <Link
            key={it.href}
            href={it.href}
            aria-current={active(it.href) ? "page" : undefined}
            className={`rounded-lg px-3 py-2 text-sm font-medium transition ${
              active(it.href)
                ? "bg-coffee-100 text-coffee-900"
                : "text-coffee-600 hover:bg-coffee-50 hover:text-coffee-900"
            }`}
          >
            {it.label === "Home" ? "Dashboard" : it.label}
          </Link>
        ))}
      </nav>
    );
  }

  const split = Math.ceil(items.length / 2);
  const tab = (it: Item) => (
    <Link
      key={it.href}
      href={it.href}
      aria-current={active(it.href) ? "page" : undefined}
      className={`flex flex-1 flex-col items-center gap-0.5 py-2 text-xs font-medium ${
        active(it.href) ? "text-coffee-800" : "text-coffee-500"
      }`}
    >
      <Icon name={it.icon} className="h-5 w-5" />
      {it.label}
    </Link>
  );

  return (
    <nav
      aria-label="Main"
      className="fixed inset-x-0 bottom-0 z-30 border-t border-coffee-100 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden"
    >
      <div className="mx-auto flex max-w-md items-end px-2">
        {items.slice(0, split).map(tab)}
        <Link
          href="/transactions/new"
          aria-label="Add payment"
          className="-mt-5 mb-2 grid h-14 w-14 shrink-0 place-items-center rounded-full bg-coffee-700 text-white shadow-lg ring-4 ring-cream active:bg-coffee-900"
        >
          <Icon name="plus" className="h-7 w-7" />
        </Link>
        {items.slice(split).map(tab)}
      </div>
    </nav>
  );
}
