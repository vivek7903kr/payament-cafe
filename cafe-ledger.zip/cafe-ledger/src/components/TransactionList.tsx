import Link from "next/link";
import type { PaymentMode } from "@prisma/client";
import { formatDateTime } from "@/lib/dates";
import { formatINR } from "@/lib/money";
import { DeleteButton } from "./DeleteButton";
import { Icon } from "./Icon";
import { ModeBadge } from "./ModeBadge";

export interface TxRow {
  id: string;
  transactionDate: Date;
  amount: { toString(): string };
  paymentMode: PaymentMode;
  orderReference: string | null;
  customerName: string | null;
  notes: string | null;
  createdBy: { name: string };
}

function summaryOf(t: TxRow) {
  return `${formatINR(t.amount)} · ${formatDateTime(t.transactionDate)}${
    t.orderReference ? ` · ${t.orderReference}` : ""
  }`;
}

function Actions({ t }: { t: TxRow }) {
  return (
    <div className="flex items-center justify-end gap-1">
      <Link
        href={`/transactions/${t.id}/edit`}
        className="inline-flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-sm font-medium text-coffee-700 hover:bg-coffee-50"
      >
        <Icon name="edit" className="h-4 w-4" />
        Edit
      </Link>
      <DeleteButton id={t.id} summary={summaryOf(t)} />
    </div>
  );
}

export function TransactionList({ rows, canManage }: { rows: TxRow[]; canManage: boolean }) {
  return (
    <>
      {/* Phones: stacked cards */}
      <ul className="divide-y divide-coffee-100 md:hidden">
        {rows.map((t) => (
          <li key={t.id} className="px-4 py-3.5">
            <div className="flex items-center justify-between gap-3">
              <span className="font-display text-xl font-semibold tabular-nums">{formatINR(t.amount)}</span>
              <ModeBadge mode={t.paymentMode} />
            </div>
            {(t.orderReference || t.customerName) && (
              <p className="mt-1 text-sm font-medium text-coffee-800">
                {[t.orderReference, t.customerName].filter(Boolean).join(" · ")}
              </p>
            )}
            {t.notes && <p className="mt-0.5 text-sm text-coffee-600">{t.notes}</p>}
            <p className="mt-1 text-xs text-coffee-500">
              {formatDateTime(t.transactionDate)} · {t.createdBy.name}
            </p>
            {canManage && (
              <div className="mt-2 -mb-1">
                <Actions t={t} />
              </div>
            )}
          </li>
        ))}
      </ul>

      {/* Tablets and desktops: table */}
      <div className="hidden overflow-x-auto md:block">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-coffee-100 text-coffee-600">
            <tr>
              <th className="px-5 py-3 font-medium">When</th>
              <th className="px-3 py-3 font-medium">Amount</th>
              <th className="px-3 py-3 font-medium">Mode</th>
              <th className="px-3 py-3 font-medium">Details</th>
              <th className="px-3 py-3 font-medium">Staff</th>
              {canManage && <th className="px-5 py-3" />}
            </tr>
          </thead>
          <tbody className="divide-y divide-coffee-100">
            {rows.map((t) => (
              <tr key={t.id} className="hover:bg-coffee-50/60">
                <td className="whitespace-nowrap px-5 py-3 text-coffee-700">{formatDateTime(t.transactionDate)}</td>
                <td className="whitespace-nowrap px-3 py-3 font-semibold tabular-nums">{formatINR(t.amount)}</td>
                <td className="px-3 py-3">
                  <ModeBadge mode={t.paymentMode} />
                </td>
                <td className="max-w-xs px-3 py-3">
                  {(t.orderReference || t.customerName) && (
                    <div className="font-medium text-coffee-800">
                      {[t.orderReference, t.customerName].filter(Boolean).join(" · ")}
                    </div>
                  )}
                  {t.notes && <div className="truncate text-coffee-600">{t.notes}</div>}
                  {!t.orderReference && !t.customerName && !t.notes && <span className="text-coffee-300">—</span>}
                </td>
                <td className="whitespace-nowrap px-3 py-3 text-coffee-700">{t.createdBy.name}</td>
                {canManage && (
                  <td className="whitespace-nowrap px-5 py-3">
                    <Actions t={t} />
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
