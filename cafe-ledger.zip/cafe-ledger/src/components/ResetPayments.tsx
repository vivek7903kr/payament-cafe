"use client";

import { useEffect, useState } from "react";
import { useFormState } from "react-dom";
import { resetAllPayments } from "@/app/actions/transactions";
import type { FormState } from "@/lib/types";
import { Icon } from "./Icon";
import { SubmitButton } from "./SubmitButton";
import { useToast } from "./Toast";

export function ResetPayments({ count }: { count: number }) {
  const [open, setOpen] = useState(false);
  const [state, action] = useFormState(resetAllPayments, { ok: false } as FormState);
  const toast = useToast();
  const errors = state.errors ?? {};

  useEffect(() => {
    if (!state.ts) return;
    if (state.ok) {
      toast.success(state.message ?? "All payments deleted");
      setOpen(false);
    } else if (state.message) {
      toast.error(state.message);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <section className="mt-8 rounded-2xl border border-red-200 bg-red-50/60 p-5">
      <h2 className="text-lg font-semibold text-red-800">Danger zone</h2>
      <p className="mt-1 max-w-2xl text-sm text-red-900/80">
        Reset deletes <strong>every payment</strong> so you can start fresh (for example after testing, or at the
        start of a new year). Users and logins are kept. This cannot be undone, so download a backup first.
      </p>
      <div className="mt-4 flex flex-wrap gap-2">
        <a href="/api/export?kind=transactions&all=1" className="btn-secondary" download>
          <Icon name="download" className="h-4 w-4" />
          Download backup (CSV)
        </a>
        <button type="button" className="btn-danger" disabled={count === 0} onClick={() => setOpen(true)}>
          <Icon name="trash" className="h-4 w-4" />
          {count === 0 ? "No payments to reset" : `Reset all ${count} payments…`}
        </button>
      </div>

      {open && (
        <div
          className="fixed inset-0 z-[90] grid place-items-end bg-coffee-900/50 p-4 sm:place-items-center"
          onClick={() => setOpen(false)}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="reset-title"
            className="card w-full max-w-md p-5"
            onClick={(e) => e.stopPropagation()}
          >
            <h2 id="reset-title" className="text-lg font-semibold text-red-700">
              Delete all {count} payments?
            </h2>
            <p className="mt-2 text-sm text-coffee-700">
              Every payment, daily total and monthly figure will be erased permanently. Have you downloaded a backup?
            </p>

            <form action={action} className="mt-4 space-y-4" noValidate>
              <div>
                <label htmlFor="reset-confirm" className="label">
                  Type <strong>RESET</strong> to confirm
                </label>
                <input
                  id="reset-confirm"
                  name="confirm"
                  autoComplete="off"
                  autoCapitalize="characters"
                  className="input"
                />
                {errors.confirm && <p className="field-error">{errors.confirm}</p>}
              </div>
              <div>
                <label htmlFor="reset-password" className="label">
                  Your admin password
                </label>
                <input
                  id="reset-password"
                  name="password"
                  type="password"
                  autoComplete="current-password"
                  className="input"
                />
                {errors.password && <p className="field-error">{errors.password}</p>}
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button type="button" className="btn-secondary" onClick={() => setOpen(false)}>
                  Cancel
                </button>
                <SubmitButton className="btn-danger" pendingLabel="Deleting…">
                  Delete everything
                </SubmitButton>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
}
