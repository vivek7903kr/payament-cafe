"use client";

import { useEffect, useState, useTransition } from "react";
import { deleteTransaction } from "@/app/actions/transactions";
import { Icon } from "./Icon";
import { useToast } from "./Toast";

export function DeleteButton({ id, summary }: { id: string; summary: string }) {
  const [open, setOpen] = useState(false);
  const [pending, start] = useTransition();
  const toast = useToast();

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && !pending && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, pending]);

  function confirmDelete() {
    start(async () => {
      const res = await deleteTransaction(id);
      if (res.ok) {
        toast.success(res.message);
        setOpen(false);
      } else {
        toast.error(res.message);
      }
    });
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-sm font-medium text-red-700 hover:bg-red-50"
      >
        <Icon name="trash" className="h-4 w-4" />
        Delete
      </button>

      {open && (
        <div
          className="fixed inset-0 z-[90] grid place-items-end bg-coffee-900/50 p-4 sm:place-items-center"
          onClick={() => !pending && setOpen(false)}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby={`del-${id}`}
            className="card w-full max-w-sm p-5"
            onClick={(e) => e.stopPropagation()}
          >
            <h2 id={`del-${id}`} className="text-lg font-semibold">
              Delete this payment?
            </h2>
            <p className="mt-2 text-sm text-coffee-700">{summary}</p>
            <p className="mt-2 text-sm text-coffee-600">
              This removes it from the day's total and can't be undone.
            </p>
            <div className="mt-5 flex justify-end gap-2">
              <button type="button" className="btn-secondary" disabled={pending} onClick={() => setOpen(false)}>
                Keep payment
              </button>
              <button type="button" className="btn-danger" disabled={pending} onClick={confirmDelete}>
                {pending ? "Deleting…" : "Delete payment"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
