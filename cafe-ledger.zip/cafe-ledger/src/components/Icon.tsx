const PATHS = {
  home: ["M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"],
  plus: ["M12 5v14", "M5 12h14"],
  calendar: ["M4 6h16v14H4z", "M4 10h16", "M8 3v4", "M16 3v4"],
  chart: ["M3 20h18", "M6 20v-7", "M12 20V5", "M18 20v-10"],
  report: ["M6 3h9l4 4v14H6z", "M14 3v5h5", "M9 13h7", "M9 17h7"],
  users: [
    "M16 20v-1a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v1",
    "M10 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z",
    "M20 20v-1a4 4 0 0 0-3-3.9",
    "M16 4.2a3.5 3.5 0 0 1 0 6.6",
  ],
  logout: ["M9 21H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h4", "M16 17l5-5-5-5", "M21 12H9"],
  edit: ["M4 20h4L19 9l-4-4L4 16z", "M13.5 6.5l4 4"],
  trash: ["M4 7h16", "M10 11v6", "M14 11v6", "M6 7l1 13h10l1-13", "M9 7V4h6v3"],
  download: ["M12 3v12", "M7 10l5 5 5-5", "M4 21h16"],
  cup: ["M5 8h11v6a5 5 0 0 1-5 5h-1a5 5 0 0 1-5-5z", "M16 9h2a2.5 2.5 0 0 1 0 5h-2", "M8 3v2", "M12 3v2"],
  search: ["M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14z", "M21 21l-4.5-4.5"],
  left: ["M15 6l-6 6 6 6"],
  right: ["M9 6l6 6-6 6"],
} as const;

export type IconName = keyof typeof PATHS;

export function Icon({ name, className = "h-5 w-5" }: { name: IconName; className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {PATHS[name].map((d) => (
        <path key={d} d={d} />
      ))}
    </svg>
  );
}
