export function StatCard({
  label,
  value,
  hint,
  featured = false,
  className = "",
}: {
  label: string;
  value: string;
  hint?: string;
  featured?: boolean;
  className?: string;
}) {
  return (
    <div
      className={`rounded-2xl p-4 md:p-5 ${
        featured ? "bg-coffee-800 text-white shadow-card" : "card"
      } ${className}`}
    >
      <p className={`text-sm ${featured ? "text-coffee-200" : "text-coffee-600"}`}>{label}</p>
      <p
        className={`mt-1 font-display font-semibold tabular-nums tracking-tight ${
          featured ? "text-4xl md:text-5xl" : "text-2xl md:text-3xl"
        }`}
      >
        {value}
      </p>
      {hint && (
        <p className={`mt-1.5 text-sm ${featured ? "text-coffee-200" : "text-coffee-500"}`}>{hint}</p>
      )}
    </div>
  );
}
