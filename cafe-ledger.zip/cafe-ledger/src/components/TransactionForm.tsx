"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useFormState } from "react-dom";
import { MODE_META, PAYMENT_MODES, type PaymentModeKey } from "@/lib/constants";
import { toDateTimeLocal } from "@/lib/dates";
import type { FormState } from "@/lib/types";
import { SubmitButton } from "./SubmitButton";
import { useToast } from "./Toast";

type Values = {
  transactionDate: string;
  amount: string;
  paymentMode: PaymentModeKey;
  orderReference: string;
  customerName: string;
  notes: string;
};

const fresh = (): Values => ({
  transactionDate: toDateTimeLocal(new Date()),
  amount: "",
  paymentMode: "CASH",
  orderReference: "",
  customerName: "",
  notes: "",
});

export function TransactionForm({
  action,
  mode,
  defaults,
  staffName,
}: {
  action: (prev: FormState, fd: FormData) => Promise<FormState>;
  mode: "create" | "edit";
  defaults: Values;
  staffName: string;
}) {
  const [state, formAction] = useFormState(action, { ok: false } as FormState);
  const [v, setV] = useState<Values>(defaults);
  const toast = useToast();
  const router = useRouter();
  const amountRef = useRef<HTMLInputElement>(null);
  const errors = state.errors ?? {};

  const set = <K extends keyof Values>(k: K, val: Values[K]) => setV((p) => ({ ...p, [k]: val }));

  useEffect(() => {
    if (!state.ts) return;
    if (state.ok) {
      toast.success(state.message ?? "Saved");
      if (mode === "create") {
        setV(fresh());
        amountRef.current?.focus();
      }
      if (state.redirectTo) router.push(state.redirectTo);
    } else if (state.message) {
      toast.error(state.message);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  return (
    <form action={formAction} className="card space-y-5 p-5 md:p-6" noValidate>
      <div>
        <label htmlFor="amount" className="label">
          Amount
        </label>
        <div className="relative">
          <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 font-display text-2xl text-coffee-500">
            ₹
          </span>
          <input
            ref={amountRef}
            id="amount"
            name="amount"
            type="text"
            inputMode="decimal"
            autoComplete="off"
            autoFocus={mode === "create"}
            placeholder="0.00"
            value={v.amount}
            onChange={(e) => set("amount", e.target.value.replace(/[^\d.]/g, ""))}
            aria-invalid={!!errors.amount}
            className="input !py-3.5 !pl-10 font-display text-3xl font-semibold tabular-nums"
          />
        </div>
        {errors.amount && <p className="field-error">{errors.amount}</p>}
      </div>

      <fieldset>
        <legend className="label">Payment mode</legend>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {PAYMENT_MODES.map((m) => (
            <label key={m} className="cursor-pointer">
              <input
                type="radio"
                name="paymentMode"
                value={m}
                checked={v.paymentMode === m}
                onChange={() => set("paymentMode", m)}
                className="peer sr-only"
              />
              <span className="flex h-12 items-center justify-center rounded-xl border border-coffee-200 bg-white text-sm font-semibold text-coffee-800 transition peer-checked:border-coffee-700 peer-checked:bg-coffee-700 peer-checked:text-white peer-focus-visible:ring-2 peer-focus-visible:ring-coffee-500 peer-focus-visible:ring-offset-2">
                {MODE_META[m].label}
              </span>
            </label>
          ))}
        </div>
        {errors.paymentMode && <p className="field-error">{errors.paymentMode}</p>}
      </fieldset>

      <div>
        <label htmlFor="transactionDate" className="label">
          Date and time <span className="font-normal text-coffee-500">(India time)</span>
        </label>
        <input
          id="transactionDate"
          name="transactionDate"
          type="datetime-local"
          value={v.transactionDate}
          onChange={(e) => set("transactionDate", e.target.value)}
          aria-invalid={!!errors.transactionDate}
          className="input"
        />
        {errors.transactionDate && <p className="field-error">{errors.transactionDate}</p>}
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="orderReference" className="label">
            Order or reference no. <span className="font-normal text-coffee-500">(optional)</span>
          </label>
          <input
            id="orderReference"
            name="orderReference"
            type="text"
            maxLength={60}
            value={v.orderReference}
            onChange={(e) => set("orderReference", e.target.value)}
            className="input"
          />
          {errors.orderReference && <p className="field-error">{errors.orderReference}</p>}
        </div>
        <div>
          <label htmlFor="customerName" className="label">
            Customer name <span className="font-normal text-coffee-500">(optional)</span>
          </label>
          <input
            id="customerName"
            name="customerName"
            type="text"
            maxLength={80}
            value={v.customerName}
            onChange={(e) => set("customerName", e.target.value)}
            className="input"
          />
          {errors.customerName && <p className="field-error">{errors.customerName}</p>}
        </div>
      </div>

      <div>
        <label htmlFor="notes" className="label">
          Notes <span className="font-normal text-coffee-500">(optional)</span>
        </label>
        <textarea
          id="notes"
          name="notes"
          rows={2}
          maxLength={500}
          value={v.notes}
          onChange={(e) => set("notes", e.target.value)}
          className="input"
        />
        {errors.notes && <p className="field-error">{errors.notes}</p>}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-coffee-100 pt-4">
        <p className="text-sm text-coffee-600">
          {mode === "create" ? "Recorded by" : "Originally recorded by"}{" "}
          <strong className="text-coffee-900">{staffName}</strong>
        </p>
        <SubmitButton className="btn-primary w-full sm:w-auto sm:min-w-40">
          {mode === "create" ? "Add payment" : "Save changes"}
        </SubmitButton>
      </div>
    </form>
  );
}
