"use client";

import { useEffect, useState } from "react";

interface InstallEvent extends Event {
  prompt: () => Promise<void>;
}

/** Phone-only banner that helps staff install the app to the home screen. */
export function InstallPrompt() {
  const [event, setEvent] = useState<InstallEvent | null>(null);
  const [ios, setIos] = useState(false);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (navigator as unknown as { standalone?: boolean }).standalone === true;
    let dismissed = false;
    try {
      dismissed = localStorage.getItem("install-dismissed") === "1";
    } catch {}
    if (standalone || dismissed) return;

    if (/iphone|ipad|ipod/i.test(navigator.userAgent)) {
      setIos(true);
      setVisible(true);
    }
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setEvent(e as InstallEvent);
      setVisible(true);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  function dismiss() {
    setVisible(false);
    try {
      localStorage.setItem("install-dismissed", "1");
    } catch {}
  }

  async function install() {
    if (!event) return;
    await event.prompt();
    setVisible(false);
  }

  if (!visible) return null;

  return (
    <div className="mb-4 flex items-start gap-3 rounded-2xl bg-coffee-800 p-4 text-white md:hidden">
      <div className="flex-1 text-sm">
        <p className="font-semibold">Install Cafe Ledger on your phone</p>
        {ios && !event ? (
          <p className="mt-1 text-coffee-200">
            Tap the <strong>Share</strong> button in Safari, then <strong>Add to Home Screen</strong>.
          </p>
        ) : (
          <p className="mt-1 text-coffee-200">Open it from your home screen like any other app.</p>
        )}
        {event && (
          <button onClick={install} className="mt-3 rounded-lg bg-white px-4 py-2 text-sm font-semibold text-coffee-900">
            Install app
          </button>
        )}
      </div>
      <button onClick={dismiss} aria-label="Dismiss" className="-mr-1 -mt-1 p-1 text-xl leading-none text-coffee-200">
        ×
      </button>
    </div>
  );
}
