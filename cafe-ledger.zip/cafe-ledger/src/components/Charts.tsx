import { MODE_META, PAYMENT_MODES } from "@/lib/constants";
import { formatINR, formatINRCompact } from "@/lib/money";
import { formatShortDate } from "@/lib/dates";
import type { DayRow, ModeTotals } from "@/lib/types";

function niceMax(v: number) {
  if (v <= 0) return 100;
  const mag = 10 ** Math.floor(Math.log10(v));
  const n = v / mag;
  return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * mag;
}

/** Simple, dependency-free SVG bar chart of revenue per day. */
export function DailyBarChart({ data }: { data: Pick<DayRow, "date" | "total">[] }) {
  const peak = Math.max(0, ...data.map((d) => d.total));
  if (peak <= 0) {
    return (
      <p className="py-10 text-center text-sm text-coffee-600">
        No revenue recorded for this period yet.
      </p>
    );
  }

  const W = 720, H = 240, padL = 52, padR = 8, padT = 12, padB = 28;
  const max = niceMax(peak);
  const innerW = W - padL - padR;
  const innerH = H - padT - padB;
  const slot = innerW / data.length;
  const bw = Math.max(2, slot * 0.68);
  const step = Math.ceil(data.length / 8);
  const label = (d: string) => (data.length <= 31 ? String(Number(d.slice(8))) : `${d.slice(8)}/${d.slice(5, 7)}`);

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      className="h-auto w-full"
      role="img"
      aria-label="Bar chart of revenue per day"
    >
      {[0, 0.5, 1].map((f) => {
        const y = padT + innerH - innerH * f;
        return (
          <g key={f}>
            <line x1={padL} x2={W - padR} y1={y} y2={y} stroke="#e6d3bd" strokeDasharray={f === 0 ? "0" : "3 4"} />
            <text x={padL - 8} y={y + 4} textAnchor="end" fontSize="11" fill="#8c5e3a">
              {formatINRCompact(max * f)}
            </text>
          </g>
        );
      })}
      {data.map((d, i) => {
        const h = (d.total / max) * innerH;
        const x = padL + i * slot + (slot - bw) / 2;
        return (
          <g key={d.date}>
            <rect
              x={x}
              y={padT + innerH - h}
              width={bw}
              height={Math.max(h, d.total > 0 ? 1 : 0)}
              rx={2}
              className="fill-coffee-500 hover:fill-coffee-800"
            >
              <title>{`${formatShortDate(d.date)}: ${formatINR(d.total)}`}</title>
            </rect>
            {i % step === 0 && (
              <text x={x + bw / 2} y={H - 8} textAnchor="middle" fontSize="11" fill="#8c5e3a">
                {label(d.date)}
              </text>
            )}
          </g>
        );
      })}
    </svg>
  );
}

/** Horizontal bars showing each payment mode's share of revenue. */
export function ModeBars({ byMode, total }: { byMode: ModeTotals; total: number }) {
  return (
    <ul className="space-y-4">
      {PAYMENT_MODES.map((m) => {
        const { total: t, count } = byMode[m];
        const pct = total > 0 ? (t / total) * 100 : 0;
        return (
          <li key={m}>
            <div className="mb-1.5 flex flex-wrap items-baseline justify-between gap-x-3 text-sm">
              <span className="flex items-center gap-2 font-medium text-coffee-900">
                <span className="h-2.5 w-2.5 rounded-full" style={{ background: MODE_META[m].color }} />
                {MODE_META[m].label}
              </span>
              <span className="tabular-nums text-coffee-600">
                <strong className="text-coffee-900">{formatINR(t)}</strong> · {pct.toFixed(0)}% · {count}{" "}
                {count === 1 ? "payment" : "payments"}
              </span>
            </div>
            <div className="h-2.5 overflow-hidden rounded-full bg-coffee-100">
              <div className="h-full rounded-full" style={{ width: `${pct}%`, background: MODE_META[m].color }} />
            </div>
          </li>
        );
      })}
    </ul>
  );
}
