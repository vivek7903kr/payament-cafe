import { PrismaClient, PaymentMode } from "@prisma/client";
import bcrypt from "bcryptjs";
import { istYmd } from "../src/lib/dates";

const prisma = new PrismaClient();

// Small deterministic PRNG so every seed run produces the same sample data
function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const PRICES = [30, 40, 60, 80, 90, 120, 150, 180, 220, 260, 320, 350, 480, 640, 900];
const CUSTOMERS = ["Neha", "Rahul", "Priya", "Sandeep", "Anjali", "Vikram", "Meera", "Imran"];
const NOTES = ["Takeaway", "Birthday order", "Extra cheese", "Corporate tab", "Cold coffee, no sugar", "Table 4"];

function pickMode(r: number): PaymentMode {
  if (r < 0.5) return "UPI";
  if (r < 0.82) return "CASH";
  if (r < 0.95) return "CARD";
  return "OTHER";
}

async function main() {
  const adminEmail = (process.env.SEED_ADMIN_EMAIL ?? "admin@cafe.local").toLowerCase();
  const adminPassword = process.env.SEED_ADMIN_PASSWORD ?? "Admin@12345";

  const admin = await prisma.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      name: "Cafe Owner",
      email: adminEmail,
      passwordHash: await bcrypt.hash(adminPassword, 12),
      role: "ADMIN",
    },
  });

  const staffPassword = "Staff@12345";
  const staff = [];
  for (const [name, email] of [
    ["Riya Sharma", "staff@cafe.local"],
    ["Aman Verma", "aman@cafe.local"],
  ]) {
    staff.push(
      await prisma.user.upsert({
        where: { email },
        update: {},
        create: { name, email, passwordHash: await bcrypt.hash(staffPassword, 12), role: "STAFF" },
      })
    );
  }

  // Re-seeding replaces only previously seeded sample rows
  await prisma.transaction.deleteMany({ where: { orderReference: { startsWith: "SEED-" } } });

  const rand = mulberry32(2026);
  const people = [admin, ...staff];
  const now = new Date();
  const data: {
    transactionDate: Date;
    amount: string;
    paymentMode: PaymentMode;
    orderReference: string;
    customerName: string | null;
    notes: string | null;
    createdByUserId: string;
  }[] = [];

  for (let back = 44; back >= 0; back--) {
    const ymd = istYmd(new Date(now.getTime() - back * 86_400_000));
    const dow = new Date(`${ymd}T00:00:00Z`).getUTCDay();
    const count = 16 + Math.floor(rand() * 14) + (dow === 0 || dow === 6 ? 10 : 0);
    for (let n = 1; n <= count; n++) {
      // Two rushes: mid-morning and early evening
      const rush = rand() < 0.5 ? 9 + rand() * 3 : 16 + rand() * 4;
      const hour = rand() < 0.75 ? rush : 8 + rand() * 14;
      const hh = String(Math.floor(hour)).padStart(2, "0");
      const mm = String(Math.floor((hour % 1) * 60)).padStart(2, "0");
      const when = new Date(`${ymd}T${hh}:${mm}:00+05:30`);
      if (when > now) continue;

      const items = 1 + Math.floor(rand() * 3);
      let amount = 0;
      for (let i = 0; i < items; i++) amount += PRICES[Math.floor(rand() * PRICES.length)];
      if (rand() < 0.1) amount += 0.5;

      data.push({
        transactionDate: when,
        amount: amount.toFixed(2),
        paymentMode: pickMode(rand()),
        orderReference: `SEED-${ymd.replace(/-/g, "")}-${String(n).padStart(3, "0")}`,
        customerName: rand() < 0.25 ? CUSTOMERS[Math.floor(rand() * CUSTOMERS.length)] : null,
        notes: rand() < 0.12 ? NOTES[Math.floor(rand() * NOTES.length)] : null,
        createdByUserId: people[Math.floor(rand() * people.length)].id,
      });
    }
  }

  await prisma.transaction.createMany({ data });

  console.log(`Seeded ${data.length} sample transactions over the last 45 days.`);
  console.log(`Admin login: ${adminEmail} / ${adminPassword}`);
  console.log(`Staff login: staff@cafe.local / ${staffPassword}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
