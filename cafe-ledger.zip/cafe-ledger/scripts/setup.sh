#!/usr/bin/env bash
# One-time setup: installs packages, creates .env, starts the database,
# creates the tables and loads sample data. Safe to run again.
set -euo pipefail
cd "$(dirname "$0")/.."

step() { printf "\n\033[1;33m▶ %s\033[0m\n" "$1"; }
ok()   { printf "\033[1;32m✔ %s\033[0m\n" "$1"; }
fail() { printf "\n\033[1;31m✖ %s\033[0m\n\n" "$1"; exit 1; }

# ---- 1. Node.js -------------------------------------------------------------
step "1/6  Checking Node.js"
command -v node >/dev/null 2>&1 || fail "Node.js is not installed.
   Install the LTS version from https://nodejs.org (or run: brew install node),
   then quit and reopen VS Code and run this again."
node -e 'const [a,b]=process.versions.node.split(".").map(Number); process.exit(a>18||(a===18&&b>=18)?0:1)' \
  || fail "Node.js $(node -v) is too old. Install the LTS version from https://nodejs.org (need 18.18 or newer)."
ok "Node.js $(node -v)"

# ---- 2. Packages ------------------------------------------------------------
step "2/6  Installing packages (first time takes 1-2 minutes)"
npm install --no-fund --no-audit
ok "Packages installed"

# ---- 3. .env ----------------------------------------------------------------
step "3/6  Preparing the .env settings file"
[ -f .env ] || cp .env.example .env
node -e '
const fs = require("fs"), crypto = require("crypto");
let t = fs.readFileSync(".env", "utf8");
const m = t.match(/^AUTH_SECRET="?([^"\n]*)"?$/m);
if (!m || m[1].length < 32 || m[1].startsWith("replace-me")) {
  const secret = crypto.randomBytes(32).toString("base64");
  const line = "AUTH_SECRET=\"" + secret + "\"";
  t = m ? t.replace(/^AUTH_SECRET=.*$/m, line) : t + "\n" + line + "\n";
  fs.writeFileSync(".env", t);
  console.log("Generated a new AUTH_SECRET");
}'
ok ".env is ready"

# ---- 4. Database ------------------------------------------------------------
step "4/6  Starting the database"
if [ "${SKIP_DOCKER:-0}" = "1" ]; then
  ok "SKIP_DOCKER=1 – using the DATABASE_URL from .env"
else
  command -v docker >/dev/null 2>&1 || fail "Docker is not installed.
   1. Install Docker Desktop: https://www.docker.com/products/docker-desktop/
      (choose 'Apple chip' or 'Intel chip' to match your Mac - Apple menu > About This Mac)
   2. Open Docker Desktop once and wait until it says it is running.
   3. Run this setup again.
   Already have your own PostgreSQL? Put its address in .env as DATABASE_URL and run:
      SKIP_DOCKER=1 npm run setup"
  docker info >/dev/null 2>&1 || fail "Docker is installed but not running.
   Open the Docker Desktop app, wait until it says it is running, then run this again."

  if docker compose version >/dev/null 2>&1; then DC="docker compose"; else DC="docker-compose"; fi
  $DC up -d db || fail "Could not start the database. If port 5432 is already in use,
   another PostgreSQL is running on your Mac - quit it, or change the port in docker-compose.yml and .env."

  printf "Waiting for the database"
  ready=0
  for i in $(seq 1 60); do
    if $DC exec -T db pg_isready -U cafe -d cafe >/dev/null 2>&1; then ready=$((ready+1)); else ready=0; fi
    [ "$ready" -ge 3 ] && break    # ready 3 checks in a row (first start restarts once)
    printf "."; sleep 1
  done
  echo
  [ "$ready" -ge 3 ] || fail "The database did not become ready in time. Run: docker compose logs db"
  ok "Database is running"
fi

# ---- 5. Tables --------------------------------------------------------------
step "5/6  Creating the database tables"
if ls prisma/migrations/*/migration.sql >/dev/null 2>&1; then
  npx prisma migrate deploy
else
  npx prisma migrate dev --name init --skip-seed
fi
ok "Tables are ready"

# ---- 6. Sample data ---------------------------------------------------------
step "6/6  Adding sample users and payments"
npm run db:seed
ok "Sample data loaded"

printf "\n\033[1;32m🎉 All set!\033[0m\n"
printf "Start the app with:  \033[1mnpm run dev:all\033[0m   (or press Cmd+Shift+B in VS Code)\n"
printf "Then open http://localhost:3000\n\n"
