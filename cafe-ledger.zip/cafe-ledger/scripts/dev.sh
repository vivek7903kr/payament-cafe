#!/usr/bin/env bash
# Starts the database (if Docker is available) and the app, then opens the browser.
set -euo pipefail
cd "$(dirname "$0")/.."

if [ ! -f .env ] || [ ! -d node_modules ]; then
  printf "\n\033[1;31m✖ First-time setup hasn't been done yet. Run:  npm run setup\033[0m\n\n"
  exit 1
fi

if [ "${SKIP_DOCKER:-0}" != "1" ] && command -v docker >/dev/null 2>&1; then
  if docker info >/dev/null 2>&1; then
    if docker compose version >/dev/null 2>&1; then DC="docker compose"; else DC="docker-compose"; fi
    $DC up -d db
    for i in $(seq 1 30); do
      $DC exec -T db pg_isready -U cafe -d cafe >/dev/null 2>&1 && break
      sleep 1
    done
  else
    printf "\n\033[1;31m✖ Docker Desktop isn't running. Open it, wait until it says running, then try again.\033[0m\n\n"
    exit 1
  fi
fi

# Open the browser once the app answers (Mac only)
if command -v open >/dev/null 2>&1; then
  ( for i in $(seq 1 90); do
      if curl -fs -o /dev/null http://localhost:3000/login; then open http://localhost:3000; break; fi
      sleep 1
    done ) &
fi

exec npm run dev
