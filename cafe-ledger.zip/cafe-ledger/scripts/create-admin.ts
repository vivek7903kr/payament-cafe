// Creates (or resets) a real admin login. Usage:
//   npm run create-admin -- you@example.com "YourStrongPassword" "Owner Name"
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const [emailArg, password, ...nameParts] = process.argv.slice(2);
  const email = (emailArg ?? "").trim().toLowerCase();
  const name = nameParts.join(" ").trim() || "Cafe Owner";

  if (!email.includes("@") || !password) {
    console.error('Usage: npm run create-admin -- you@example.com "YourStrongPassword" "Owner Name"');
    process.exit(1);
  }
  if (password.length < 8) {
    console.error("The password must be at least 8 characters.");
    process.exit(1);
  }

  const passwordHash = await bcrypt.hash(password, 12);
  await prisma.user.upsert({
    where: { email },
    update: { passwordHash, role: "ADMIN", active: true, name },
    create: { email, name, passwordHash, role: "ADMIN" },
  });
  console.log(`Admin ready: ${email}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
