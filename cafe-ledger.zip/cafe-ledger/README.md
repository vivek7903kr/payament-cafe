# Cafe Ledger

A simple, mobile-friendly payment tracker for a small cafe: record every sale, see today's income at a glance, and review monthly revenue and custom reports.

**Stack:** Next.js 14 (App Router) · React · TypeScript · Tailwind CSS · PostgreSQL · Prisma

## Features

| Area | What it does |
| --- | --- |
| Dashboard | Today's income, cash, UPI, transaction count, current-month revenue (admin), recent transactions |
| Add payment | Date/time (defaults to now, editable), amount, mode (Cash/UPI/Card/Other), order ref, customer, notes. Staff identity is taken from the login |
| Daily income | Any day's transactions, total, payment-mode breakdown, search + filters (date, mode, amount range, staff). Admins can edit and delete (delete asks for confirmation) |
| Monthly revenue | Month selector, total, average per day, transaction count, best day, daily bar chart, payment-mode chart, CSV download |
| Reports | Custom date range, totals, revenue by mode, daily chart + table, CSV download |
| Users (admin) | Add users, change roles, deactivate, reset passwords |
| Reset payments (admin) | Users page → Danger zone. Downloads a backup, then deletes every payment so you can start fresh. Needs typing RESET and your password. Users are kept |

### Roles

| | Admin | Staff |
| --- | :---: | :---: |
| Add payments | ✓ | ✓ |
| View today's payments | ✓ | ✓ |
| View other days, monthly page, reports, exports | ✓ | – |
| Edit / delete payments | ✓ | – |
| Manage users | ✓ | – |
| Month revenue on dashboard | ✓ | – |

Permissions are enforced on the server: middleware checks the signed session, and every page, server action and the export endpoint re-checks the user and role against the database.

## Quick start in VS Code (Mac)

1. Install **Node.js LTS** (nodejs.org) and **Docker Desktop** (docker.com). Open Docker Desktop once and wait until it says it is running.
2. Unzip the project, open VS Code, choose **File → Open Folder…** and pick the `cafe-ledger` folder. Click **Yes, I trust the authors**.
3. Open the terminal with **Ctrl + `** and run, once only:
   ```bash
   npm run setup
   ```
4. From then on, press **Cmd + Shift + B** (or run `npm run dev:all`). It starts the database and the app and opens http://localhost:3000.

Sign in with `admin@cafe.local` / `Admin@12345`. Stop the app with **Ctrl + C**.

No Docker? Put your own PostgreSQL address in `.env` as `DATABASE_URL`, then run `SKIP_DOCKER=1 npm run setup` and `SKIP_DOCKER=1 npm run dev:all`.

The manual steps below do the same thing if you prefer them.

## Setup (local, manual)

You need Node.js 18.18+ and PostgreSQL. Docker is the quickest way to get Postgres.

```bash
# 1. Install dependencies
npm install

# 2. Create your environment file
cp .env.example .env
#    then set AUTH_SECRET to a long random value:
#    openssl rand -base64 32

# 3. Start PostgreSQL (skip if you already have one; update DATABASE_URL to match)
docker compose up -d

# 4. Create the tables (also creates prisma/migrations the first time)
npx prisma migrate dev --name init

# 5. Add the sample admin, staff users and ~45 days of sample payments
npm run db:seed

# 6. Run the app
npm run dev
```

Open http://localhost:3000.

**Seeded logins**

| Role | Email | Password |
| --- | --- | --- |
| Admin | `admin@cafe.local` | `Admin@12345` |
| Staff | `staff@cafe.local` | `Staff@12345` |

Change these (Users page) before using the app for real. You can set `SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD` in `.env` before seeding. Re-running the seed only replaces sample rows (references starting with `SEED-`), never real payments.

**Requirements:** Node.js 18.18+ (`node -v`) and either Docker Desktop or a local PostgreSQL.

**Next time you want to run it**, you only need:

```bash
docker compose up -d    # starts the database if it isn't already running
npm run dev
```

**Open it on your phone:** connect the phone to the same Wi-Fi and visit `http://<your-computer-ip>:3000`. If it doesn't load, start the server with `npx next dev -H 0.0.0.0`.

**Without Docker:** install PostgreSQL, create a database and user, then set `DATABASE_URL` in `.env`, for example `postgresql://youruser:yourpassword@localhost:5432/cafe?schema=public`. Continue from step 4.

### Troubleshooting

| Problem | Fix |
| --- | --- |
| `AUTH_SECRET must be set` | `.env` is missing, or the secret is shorter than 32 characters. Generate one with `node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"` |
| `Can't reach database server at localhost:5432` | The database isn't running. Open Docker Desktop and run `docker compose up -d` |
| Port 5432 already in use | Another PostgreSQL is running. Stop it, or change the port in `docker-compose.yml` and `DATABASE_URL` |
| Fonts don't load | The app downloads Google Fonts, so the first run needs internet |

## Environment variables

| Variable | Purpose |
| --- | --- |
| `DATABASE_URL` | PostgreSQL connection string |
| `AUTH_SECRET` | Signs login cookies. 32+ random characters; required |
| `SEED_ADMIN_EMAIL`, `SEED_ADMIN_PASSWORD` | Only used by `npm run db:seed` |

## Commands

| Command | What it does |
| --- | --- |
| `npm run dev` | Dev server |
| `npm run build` / `npm start` | Production build / server |
| `npm run typecheck` | TypeScript check |
| `npm run db:migrate` | Create/apply migrations in development |
| `npm run db:deploy` | Apply committed migrations in production |
| `npm run db:seed` | Load sample data |
| `npm run db:push` | Create tables directly (used for first hosted setup) |
| `npm run create-admin -- email "password" "Name"` | Create or reset a real admin login |
| `npm run db:studio` | Browse the database in Prisma Studio |

## Put it on GitHub

1. Install Git (git-scm.com) and create a GitHub account.
2. On GitHub click **+ → New repository**. Name it `cafe-ledger`, choose **Private**, and leave "Add a README / .gitignore / license" **unchecked**.
3. In the project folder run:

```bash
git init
git add .
git status        # check that .env and node_modules are NOT listed
git commit -m "Initial commit: Cafe Ledger"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/cafe-ledger.git
git push -u origin main
```

When Git asks for a password, use a **personal access token** (GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic), with the `repo` scope). Your account password won't work. GitHub Desktop or `gh auth login` also handle sign-in for you.

Make sure the `prisma/migrations` folder (created by `npx prisma migrate dev --name init`) is committed, because production needs it.

**Never commit `.env`.** It holds your `AUTH_SECRET` and database password, and `.gitignore` already excludes it. If you ever push it by mistake, change both secrets immediately, then run `git rm --cached .env`, commit and push.

To save later changes:

```bash
git add .
git commit -m "Describe what you changed"
git push
```

If `git remote add` says "remote origin already exists", run `git remote remove origin` and try again.

## Install on your phone (as an app)

The app is a Progressive Web App (PWA): it installs from the browser, gets its own home-screen icon, and opens full-screen with no browser bars. It is not listed in the App Store or Play Store.

A phone can't reach `localhost` on your Mac, so the app must be hosted online first. The free tiers of **Neon** (database) and **Vercel** (hosting) work well. No Docker is needed.

### 1. Put the code on GitHub
Follow "Put it on GitHub" above. Keep the repository **Private**.

### 2. Create the database on Neon
1. Sign up at neon.tech and click **Create project**. Choose the **Singapore** region (closest to India).
2. On the project dashboard click **Connect**. **Turn off "Connection pooling"**, then copy the connection string. It starts with `postgresql://` and ends with `?sslmode=require`.

### 3. Create the tables and your admin login (from your Mac)
In the project folder, open `.env`, replace the `DATABASE_URL` line with the Neon string (keep the quotes), then run:

```bash
npm install
npm run db:push
npm run create-admin -- you@example.com "YourStrongPassword" "Your Name"
```

Optional: `npm run db:seed` adds sample payments for testing. Skip it for a clean start.

### 4. Deploy on Vercel
1. Sign up at vercel.com with your GitHub account.
2. Click **Add New → Project**, pick the `cafe-ledger` repository, and click **Import**.
3. Open **Environment Variables** and add:
   - `DATABASE_URL`: the Neon string from step 2
   - `AUTH_SECRET`: a long random value (`node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"`)
4. Click **Deploy**. After about two minutes you get an address like `https://cafe-ledger-xxxx.vercel.app`.

Each time you push to GitHub, Vercel redeploys automatically.

### 5. Install it on the phone
- **iPhone (Safari):** open your address, tap the **Share** button, then **Add to Home Screen**, then **Add**.
- **Android (Chrome):** open your address, tap the **⋮** menu, then **Install app** (or **Add to Home screen**).

The app appears on the home screen as "Cafe Ledger". Staff can do the same. Create their logins on the **Users** page.

**Good to know**
- Payments need an internet connection. If the phone is offline, the app shows a "No internet connection" page instead of saving anything.
- Vercel's free Hobby plan is meant for personal, non-commercial use. A business should check Vercel's current terms and pricing, or use another host that runs Next.js (Railway and Render are two).
- Back up your data: Neon's dashboard lets you export, or run `pg_dump` with your connection string.

### Updating the database later
`db:push` is fine for the first setup. Once real data exists, change the schema with `npm run db:migrate` locally, commit the generated `prisma/migrations` folder, and apply it in production with `npm run db:deploy`.

## Design notes

- **Money:** stored as `NUMERIC(12,2)`. Amounts are validated as strings and passed to Postgres without ever becoming floating-point numbers. Totals are summed by the database.
- **Time zone:** timestamps are stored as `timestamptz`. All day and month boundaries, the "default to now" value and displayed times use India Standard Time (`Asia/Kolkata`), whatever the server's or phone's timezone.
- **Totals come from the database:** the dashboard, daily page, monthly page and reports run `SUM`/`COUNT` queries on every request. Nothing is calculated from client state.
- **Indexes:** `transaction_date`, `payment_mode`, and `(transaction_date, payment_mode)` keep range reports fast.
- **Validation:** all inputs are validated on the server with Zod; the browser form is only a convenience.
- **Exports:** CSV with a UTF-8 BOM so Excel opens it correctly. Text cells starting with `= + - @` are prefixed to prevent spreadsheet formula injection. Amount columns are plain numbers so they can be summed.
- **Sessions:** signed HTTP-only cookie (7 days), re-checked against the database so deactivated users are locked out immediately. Passwords are hashed with bcrypt. Failed logins are rate-limited per email (per server instance).
- **Users with payments can't be deleted** (it would orphan history); deactivate them instead.

## Project layout

```
prisma/            schema.prisma, seed.ts
src/middleware.ts  session gate for every route
src/lib/           auth, db, queries (SUM/COUNT), dates (IST), money (₹), validation
src/app/actions/   server actions: auth, transactions, users
src/app/api/export CSV export (admin only)
src/app/(app)/     dashboard, daily, monthly, reports, users, transactions
src/components/    UI components, SVG charts
```
