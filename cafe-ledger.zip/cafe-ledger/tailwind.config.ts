import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        coffee: {
          50: "#faf6f1",
          100: "#f3eadf",
          200: "#e6d3bd",
          300: "#d4b595",
          400: "#bf9468",
          500: "#a8774a",
          600: "#8c5e3a",
          700: "#6f4a30",
          800: "#5a3c2a",
          900: "#3e2a1e",
        },
        cream: "#fbf8f4",
      },
      fontFamily: {
        sans: ["var(--font-body)", "system-ui", "sans-serif"],
        display: ["var(--font-display)", "Georgia", "serif"],
      },
      boxShadow: {
        card: "0 1px 2px rgba(62,42,30,.05), 0 4px 16px rgba(62,42,30,.06)",
      },
    },
  },
  plugins: [],
};
export default config;
